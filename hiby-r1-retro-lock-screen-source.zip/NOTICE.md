# Attribution and modification notice

This repository is based on [Starnished66/compas-player](https://github.com/Starnished66/compas-player) at commit `e2a029f8e99a67300c6bce635d381d8a0bfd9ed2` and remains licensed under GNU GPL version 3.

The Compás Player project, firmware tooling, player architecture, and most source files were created by their upstream authors and contributors. This fork adds a conditional retro lock-screen presentation, associated background assets, a 10-second display-timeout option, and documentation for those changes.

Compás Player itself acknowledges earlier HiBy reverse-engineering and firmware work, including `hiby-modding/hiby_os_crack` and `bidhata/Hiby-R1-Mod`. Their inclusion in the upstream history does not transfer authorship of their work to this fork.

“HiBy” is a trademark of its owner. “Game Boy” and Nintendo are trademarks of Nintendo. This is an unofficial fan customization and is not endorsed by HiBy or Nintendo.
