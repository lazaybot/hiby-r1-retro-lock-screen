/* pthread_timedjoin_np (net_connect_timeout's bounded DNS resolution below)
 * is a musl/glibc extension gated behind _GNU_SOURCE -- must be defined
 * before any system header pulls in pthread.h transitively, so this has to
 * be the file's very first line. */
#define _GNU_SOURCE

#include "http_conn.h"
#include "http_client.h" /* for struct http_cancel_token's real definition */
#include "ca_bundle.h"

#include <string.h>
#include <strings.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>

bool http_conn_parse_url(const char * url, bool * out_https, char * host, size_t host_size,
                          char * port, size_t port_size, char * path, size_t path_size) {
    const char * p;
    if (strncasecmp(url, "https://", 8) == 0) { *out_https = true; p = url + 8; }
    else if (strncasecmp(url, "http://", 7) == 0) { *out_https = false; p = url + 7; }
    else return false;

    const char * host_start = p;
    const char * host_end = p;
    while (*host_end && *host_end != ':' && *host_end != '/') host_end++;
    size_t host_len = (size_t) (host_end - host_start);
    if (host_len == 0 || host_len >= host_size) return false;
    memcpy(host, host_start, host_len);
    host[host_len] = '\0';

    p = host_end;
    if (*p == ':') {
        p++;
        const char * port_start = p;
        while (*p && *p != '/') p++;
        size_t port_len = (size_t) (p - port_start);
        if (port_len == 0 || port_len >= port_size) return false;
        memcpy(port, port_start, port_len);
        port[port_len] = '\0';
    } else {
        snprintf(port, port_size, "%s", *out_https ? "443" : "80");
    }

    /* A "#fragment" is purely client-side (RFC 3986) and must never be sent
     * to the server -- strip it before it becomes part of the request path.
     * (audio.c's decoder_open() deliberately relies on this: it reads a
     * "#.<ext>" suffix off a stream URL as a local-only format hint before
     * ever handing the URL to this function, so the fragment must not leak
     * into the actual HTTP request line.) */
    const char * frag = strchr(p, '#');
    size_t p_len = frag ? (size_t) (frag - p) : strlen(p);

    if (p_len == 0) {
        snprintf(path, path_size, "/");
    } else {
        snprintf(path, path_size, "%.*s", (int) p_len, p);
    }
    return true;
}

static uint64_t monotonic_now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t) ts.tv_sec * 1000ULL + (uint64_t) ts.tv_nsec / 1000000ULL;
}

static bool cancel_requested_conn(struct http_cancel_token * cancel) {
    if (!cancel) return false;
    pthread_mutex_lock(&cancel->mutex);
    bool requested = cancel->cancel_requested;
    pthread_mutex_unlock(&cancel->mutex);
    return requested;
}

/* Registers fd into cancel (compare-and-set: only succeeds if the token
 * hasn't already been cancelled). Returns false if cancellation raced us
 * -- caller should abandon fd immediately in that case. */
static bool cancel_register(struct http_cancel_token * cancel, int fd) {
    if (!cancel) return true;
    pthread_mutex_lock(&cancel->mutex);
    bool already = cancel->cancel_requested;
    if (!already) cancel->fd = fd;
    pthread_mutex_unlock(&cancel->mutex);
    return !already;
}

/* Unregisters fd from cancel token and closes fd atomically under cancel mutex. */
static void cancel_unregister_and_close(struct http_cancel_token * cancel, int fd) {
    if (!cancel) {
        close(fd);
        return;
    }
    pthread_mutex_lock(&cancel->mutex);
    if (cancel->fd == fd) cancel->fd = -1;
    close(fd);
    pthread_mutex_unlock(&cancel->mutex);
}

/* getaddrinfo() has no timeout parameter of its own and is not interruptible
 * mid-call -- on a Wi-Fi network where DNS packets are silently dropped
 * (association succeeds, so the radio-level guard callers already run
 * passes, but the resolver never gets a reply) it can block far longer than
 * connect_timeout_ms, or effectively forever, with no way for a caller's
 * cancel token to take effect (real-device report: Subsonic's "Connecting
 * to server..." busy overlay never dismissing). Run it on its own thread and
 * bound the WAIT with pthread_timedjoin_np instead of bounding the call
 * itself, which can't be done for a blocking libc function.
 *
 * Ownership handoff on timeout: the resolver thread is still running when
 * the caller gives up, so the caller must not free/touch ctx or ctx->result
 * -- the thread itself takes over that responsibility (checked via
 * ctx->abandoned under ctx->mutex) once getaddrinfo() finally returns,
 * detaching itself so the OS reclaims its resources without anyone having
 * to join it. This deliberately leaks a small ctx struct and one thread
 * stack until that eventually-returning call completes -- an accepted
 * tradeoff for turning an unbounded hang into a bounded one. */
typedef struct {
    char host[256];
    char port[16];
    pthread_mutex_t mutex;
    bool abandoned; /* caller gave up waiting; thread must clean up on exit */
    bool done;      /* thread finished; only meaningful while NOT abandoned */
    int rc;
    struct addrinfo * result;
} dns_resolve_ctx_t;

static void * dns_resolve_thread_func(void * arg) {
    dns_resolve_ctx_t * ctx = (dns_resolve_ctx_t *) arg;

    struct addrinfo hints, * addr_list = NULL;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    int rc = getaddrinfo(ctx->host, ctx->port, &hints, &addr_list);

    pthread_mutex_lock(&ctx->mutex);
    if (ctx->abandoned) {
        pthread_mutex_unlock(&ctx->mutex);
        if (rc == 0) freeaddrinfo(addr_list);
        pthread_mutex_destroy(&ctx->mutex);
        free(ctx);
        pthread_detach(pthread_self());
        return NULL;
    }
    ctx->rc = rc;
    ctx->result = (rc == 0) ? addr_list : NULL;
    ctx->done = true;
    pthread_mutex_unlock(&ctx->mutex);
    return NULL;
}

/* Bounded getaddrinfo(): returns 0 and *out_result on success, matching
 * getaddrinfo()'s own return convention, or a nonzero sentinel
 * (DNS_RESOLVE_TIMED_OUT) distinct from any real getaddrinfo() error code
 * when the deadline passes before the resolver thread finishes.
 * timeout_ms == 0 means "wait indefinitely" (same convention connect_
 * timeout_ms already uses), matching plain getaddrinfo()'s own blocking
 * behavior for that case. */
#define DNS_RESOLVE_TIMED_OUT (-1000)
static int dns_resolve_bounded(const char * host, const char * port, uint32_t timeout_ms,
                               struct addrinfo ** out_result) {
    dns_resolve_ctx_t * ctx = calloc(1, sizeof(*ctx));
    if (!ctx) return EAI_MEMORY;
    snprintf(ctx->host, sizeof(ctx->host), "%s", host);
    snprintf(ctx->port, sizeof(ctx->port), "%s", port);
    pthread_mutex_init(&ctx->mutex, NULL);

    pthread_t thread;
    if (pthread_create(&thread, NULL, dns_resolve_thread_func, ctx) != 0) {
        /* Thread creation itself failing is rare and not the hang this
         * exists to guard against -- fall back to a direct blocking call
         * rather than failing the request outright. */
        pthread_mutex_destroy(&ctx->mutex);
        free(ctx);
        struct addrinfo hints;
        memset(&hints, 0, sizeof(hints));
        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_protocol = IPPROTO_TCP;
        return getaddrinfo(host, port, &hints, out_result);
    }

    struct timespec deadline;
    clock_gettime(CLOCK_REALTIME, &deadline);
    uint64_t deadline_ns = (uint64_t) deadline.tv_nsec + (uint64_t) timeout_ms * 1000000ULL;
    deadline.tv_sec += (time_t) (deadline_ns / 1000000000ULL);
    deadline.tv_nsec = (long) (deadline_ns % 1000000000ULL);

    int join_rc = timeout_ms > 0 ? pthread_timedjoin_np(thread, NULL, &deadline)
                                  : pthread_join(thread, NULL);
    if (join_rc == 0) {
        int rc = ctx->rc;
        *out_result = ctx->result;
        pthread_mutex_destroy(&ctx->mutex);
        free(ctx);
        return rc;
    }

    /* Timed out (or some other join failure) -- the thread may still be
     * blocked inside getaddrinfo(). Hand ctx off to it via the abandoned
     * flag rather than freeing something it might still write into. */
    pthread_mutex_lock(&ctx->mutex);
    ctx->abandoned = true;
    bool already_done = ctx->done;
    struct addrinfo * leftover = already_done ? ctx->result : NULL;
    int leftover_rc = already_done ? ctx->rc : 0;
    pthread_mutex_unlock(&ctx->mutex);
    if (already_done) {
        /* Vanishingly rare race: it finished between the join timing out
         * and this lock -- reclaim ctx ourselves instead of leaving the
         * thread to do it, and use the real result. */
        pthread_join(thread, NULL);
        pthread_mutex_destroy(&ctx->mutex);
        free(ctx);
        if (leftover_rc == 0) { *out_result = leftover; return 0; }
        return leftover_rc;
    }
    return DNS_RESOLVE_TIMED_OUT;
}

/* Connects to host:port with a timeout using non-blocking connect() and poll().
 * Registers socket into cancel token to allow cancellation during connect. */
static http_conn_error_t net_connect_timeout(mbedtls_net_context * ctx, const char * host, const char * port,
                                              uint32_t connect_timeout_ms, struct http_cancel_token * cancel) {
    if (cancel_requested_conn(cancel)) return HTTP_CONN_ERR_CANCELLED;

    struct addrinfo * addr_list, * cur;
    int dns_rc = dns_resolve_bounded(host, port, connect_timeout_ms, &addr_list);
    if (dns_rc == DNS_RESOLVE_TIMED_OUT) return HTTP_CONN_ERR_DNS_TIMEOUT;
    if (dns_rc != 0) return HTTP_CONN_ERR_DNS;

    if (cancel_requested_conn(cancel)) { freeaddrinfo(addr_list); return HTTP_CONN_ERR_CANCELLED; }

    http_conn_error_t result = HTTP_CONN_ERR_CONNECT;
    for (cur = addr_list; cur != NULL; cur = cur->ai_next) {
        int fd = socket(cur->ai_family, cur->ai_socktype, cur->ai_protocol);
        if (fd < 0) { result = HTTP_CONN_ERR_SOCKET; continue; }

        if (!cancel_register(cancel, fd)) {
            close(fd);
            result = HTTP_CONN_ERR_CANCELLED;
            break;
        }

        int flags = fcntl(fd, F_GETFL, 0);
        fcntl(fd, F_SETFL, flags | O_NONBLOCK);

        bool connected = connect(fd, cur->ai_addr, cur->ai_addrlen) == 0;
        if (!connected && errno == EINPROGRESS) {
            struct pollfd pfd = { .fd = fd, .events = POLLOUT, .revents = 0 };
            /* poll()'s own -1 means "wait indefinitely" -- exactly
             * connect_timeout_ms == 0's intended meaning, and shutdown()
             * (from a cancel) still unblocks it immediately either way. */
            int pr = poll(&pfd, 1, connect_timeout_ms > 0 ? (int) connect_timeout_ms : -1);
            if (pr == 0) {
                cancel_unregister_and_close(cancel, fd);
                result = HTTP_CONN_ERR_CONNECT_TIMEOUT;
                continue;
            }
            if (pr < 0) {
                bool cancelled = cancel_requested_conn(cancel);
                cancel_unregister_and_close(cancel, fd);
                result = cancelled ? HTTP_CONN_ERR_CANCELLED : HTTP_CONN_ERR_CONNECT;
                continue;
            }
            int so_error = 0;
            socklen_t so_len = sizeof(so_error);
            connected = getsockopt(fd, SOL_SOCKET, SO_ERROR, &so_error, &so_len) == 0 && so_error == 0;
        }
        if (!connected) {
            bool cancelled = cancel_requested_conn(cancel);
            cancel_unregister_and_close(cancel, fd);
            result = cancelled ? HTTP_CONN_ERR_CANCELLED : HTTP_CONN_ERR_CONNECT;
            continue;
        }

        fcntl(fd, F_SETFL, flags); /* back to blocking for the rest of this connection's life */
        ctx->fd = fd;
        result = HTTP_CONN_OK;
        break;
    }

    freeaddrinfo(addr_list);
    return result;
}

bool http_conn_open_ex(http_conn_t * conn, const char * host, const char * port, bool https, bool verify_tls,
                        uint32_t connect_timeout_ms, uint32_t read_timeout_ms,
                        struct http_cancel_token * cancel, http_conn_error_t * out_error) {
    http_conn_error_t local_error = HTTP_CONN_OK;
    if (!out_error) out_error = &local_error;
    *out_error = HTTP_CONN_OK;

    memset(conn, 0, sizeof(*conn));
    conn->is_https = https;
    conn->cancel_token = cancel;
    mbedtls_net_init(&conn->net);

    *out_error = net_connect_timeout(&conn->net, host, port, connect_timeout_ms, cancel);
    if (*out_error != HTTP_CONN_OK) return false;

    if (read_timeout_ms > 0) {
        struct timeval tv = { .tv_sec = (time_t) (read_timeout_ms / 1000), .tv_usec = (suseconds_t) (read_timeout_ms % 1000) * 1000 };
        setsockopt(conn->net.fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        setsockopt(conn->net.fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    }

    if (!https) return true;

    mbedtls_ssl_init(&conn->ssl);
    mbedtls_ssl_config_init(&conn->conf);
    mbedtls_x509_crt_init(&conn->cacert);
    mbedtls_ctr_drbg_init(&conn->ctr_drbg);
    mbedtls_entropy_init(&conn->entropy);
    conn->ssl_initialized = true;

    if (mbedtls_ctr_drbg_seed(&conn->ctr_drbg, mbedtls_entropy_func, &conn->entropy, NULL, 0) != 0) {
        *out_error = HTTP_CONN_ERR_TLS_SETUP;
        return false;
    }

    if (mbedtls_ssl_config_defaults(&conn->conf, MBEDTLS_SSL_IS_CLIENT, MBEDTLS_SSL_TRANSPORT_STREAM,
                                     MBEDTLS_SSL_PRESET_DEFAULT) != 0) {
        *out_error = HTTP_CONN_ERR_TLS_SETUP;
        return false;
    }
    mbedtls_ssl_conf_rng(&conn->conf, mbedtls_ctr_drbg_random, &conn->ctr_drbg);

    if (verify_tls) {
        if (mbedtls_x509_crt_parse(&conn->cacert, ca_bundle_pem, ca_bundle_pem_len) < 0) {
            *out_error = HTTP_CONN_ERR_TLS_SETUP;
            return false;
        }
        mbedtls_ssl_conf_ca_chain(&conn->conf, &conn->cacert, NULL);
        mbedtls_ssl_conf_authmode(&conn->conf, MBEDTLS_SSL_VERIFY_REQUIRED);
    } else {
        /* Explicit, per-connection opt-out (subsonic_client.h's
         * "trust this self-signed server" setting) -- never a silent
         * default. */
        mbedtls_ssl_conf_authmode(&conn->conf, MBEDTLS_SSL_VERIFY_NONE);
    }

    if (mbedtls_ssl_setup(&conn->ssl, &conn->conf) != 0) {
        *out_error = HTTP_CONN_ERR_TLS_SETUP;
        return false;
    }
    if (mbedtls_ssl_set_hostname(&conn->ssl, host) != 0) {
        *out_error = HTTP_CONN_ERR_TLS_SETUP;
        return false;
    }
    mbedtls_ssl_set_bio(&conn->ssl, &conn->net, mbedtls_net_send, mbedtls_net_recv, NULL);

    /* Correction to the comment this replaced: it assumed a SO_RCVTIMEO
     * timeout surfaces as MBEDTLS_ERR_SSL_WANT_READ. On this fd it does
     * not -- see http_conn_read()'s own comment for the full explanation
     * (net_would_block() only ever fires for a non-blocking fd, and this
     * connection is deliberately restored to blocking after connect).
     * An EAGAIN here instead makes mbedtls_ssl_handshake() surface a
     * real, non-WANT_READ/WRITE error from its underlying f_recv -- which
     * would previously have been misreported as a bare handshake failure
     * on the very first timeout, never even reaching the wall-clock
     * check below. Check errno for EAGAIN/EWOULDBLOCK the same way
     * http_conn_read() does, immediately after the call, and treat it as
     * the equivalent of WANT_READ so the deadline logic below actually
     * runs. Retrying unconditionally on would-block (as the original,
     * timeout-less version of this loop did) would silently turn a real
     * socket timeout into an infinite retry loop instead of a bounded
     * failure -- track wall-clock elapsed time explicitly and give up
     * once it exceeds read_timeout_ms, only when a timeout was actually
     * requested; read_timeout_ms == 0 keeps the original
     * unconditional-retry behavior exactly. A cancel-driven shutdown()
     * during this loop instead surfaces as a clean EOF (recv() returning
     * 0) from the transport, which mbedTLS turns into a real (non-would-
     * block) handshake error -- already correctly handled by the
     * existing "not would-block" branch. */
    uint64_t handshake_deadline = read_timeout_ms > 0 ? monotonic_now_ms() + read_timeout_ms : 0;
    int ret;
    for (;;) {
        errno = 0;
        ret = mbedtls_ssl_handshake(&conn->ssl);
        if (ret == 0) break;
        bool would_block = (ret == MBEDTLS_ERR_SSL_WANT_READ || ret == MBEDTLS_ERR_SSL_WANT_WRITE) ||
                            (errno == EAGAIN || errno == EWOULDBLOCK);
        if (!would_block) {
            *out_error = cancel_requested_conn(cancel) ? HTTP_CONN_ERR_CANCELLED : HTTP_CONN_ERR_TLS_HANDSHAKE;
            return false;
        }
        if (handshake_deadline != 0 && monotonic_now_ms() >= handshake_deadline) {
            *out_error = HTTP_CONN_ERR_TLS_HANDSHAKE_TIMEOUT;
            return false;
        }
    }

    if (verify_tls && mbedtls_ssl_get_verify_result(&conn->ssl) != 0) {
        *out_error = HTTP_CONN_ERR_TLS_VERIFY;
        return false;
    }
    return true;
}

bool http_conn_open(http_conn_t * conn, const char * host, const char * port, bool https, bool verify_tls) {
    return http_conn_open_ex(conn, host, port, https, verify_tls, 0, 0, NULL, NULL);
}

int http_conn_write(http_conn_t * conn, const uint8_t * data, size_t len) {
    if (conn->is_https) return mbedtls_ssl_write(&conn->ssl, data, len);
    return mbedtls_net_send(&conn->net, data, len);
}

int http_conn_read(http_conn_t * conn, uint8_t * buf, size_t len) {
    errno = 0;
    int n = conn->is_https ? mbedtls_ssl_read(&conn->ssl, buf, len) : mbedtls_net_recv(&conn->net, buf, len);
    if (n == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY) {
        conn->last_read_timed_out = false;
        return 0;
    }
    /* Check errno directly for timeout (EAGAIN/EWOULDBLOCK) in addition to
     * mbedTLS want-read/want-write status codes. */
    conn->last_read_timed_out = (n == MBEDTLS_ERR_SSL_WANT_READ || n == MBEDTLS_ERR_SSL_WANT_WRITE) ||
                                 (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK));
    return n;
}

void http_conn_close(http_conn_t * conn) {
    if (conn->is_https) {
        if (conn->ssl_initialized) {
            mbedtls_ssl_close_notify(&conn->ssl);
            mbedtls_ssl_free(&conn->ssl);
            mbedtls_ssl_config_free(&conn->conf);
            mbedtls_x509_crt_free(&conn->cacert);
            mbedtls_ctr_drbg_free(&conn->ctr_drbg);
            mbedtls_entropy_free(&conn->entropy);
        }
    }
    /* Unregister from cancel token and free network context under cancel mutex. */
    struct http_cancel_token * cancel = conn->cancel_token;
    if (cancel) {
        pthread_mutex_lock(&cancel->mutex);
        if (cancel->fd == conn->net.fd) cancel->fd = -1;
        mbedtls_net_free(&conn->net);
        pthread_mutex_unlock(&cancel->mutex);
    } else {
        mbedtls_net_free(&conn->net);
    }
}

static int reader_fill(http_conn_reader_t * r) {
    r->pos = 0;
    int n = http_conn_read(r->conn, r->buf, sizeof(r->buf));
    r->len = (n > 0) ? (size_t) n : 0;
    return n;
}

bool http_conn_reader_line(http_conn_reader_t * r, char * out, size_t out_size) {
    size_t out_pos = 0;
    for (;;) {
        if (r->pos >= r->len) {
            int n = reader_fill(r);
            if (n <= 0) return false;
        }
        uint8_t c = r->buf[r->pos++];
        if (c == '\n') {
            if (out_pos > 0 && out[out_pos - 1] == '\r') out_pos--;
            out[out_pos] = '\0';
            return true;
        }
        if (out_pos + 1 < out_size) out[out_pos++] = (char) c;
    }
}

bool http_conn_reader_read_exact(http_conn_reader_t * r, uint8_t * out, size_t n) {
    size_t got = 0;
    while (got < n) {
        if (r->pos >= r->len) {
            int rn = reader_fill(r);
            if (rn <= 0) return false;
        }
        size_t avail = r->len - r->pos;
        size_t want = n - got;
        size_t take = avail < want ? avail : want;
        memcpy(out + got, r->buf + r->pos, take);
        r->pos += take;
        got += take;
    }
    return true;
}

int http_conn_reader_read_some(http_conn_reader_t * r, uint8_t * buf, size_t len) {
    if (r->pos < r->len) {
        size_t avail = r->len - r->pos;
        size_t take = avail < len ? avail : len;
        memcpy(buf, r->buf + r->pos, take);
        r->pos += take;
        return (int) take;
    }
    return http_conn_read(r->conn, buf, len);
}
