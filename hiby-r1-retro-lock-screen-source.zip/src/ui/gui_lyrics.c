#include "gui_lyrics.h"
#include "i18n.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdatomic.h>
#include "lvgl/lvgl.h"
#include "assets.h"
#include "gui.h"
#include "screen_builders.h"

#include "settings.h"
#include "metadata.h"
#include <limits.h>

#include "lyrics.h"
#include "lyrics_layout.h"
#include "frosted_glass.h"
#include "fallback_font.h"
#include "db_log.h"

typedef struct {
    int tier;
    const char * label;
} lyrics_font_size_option_t;

/* The full lyrics screen, not the player's own cover+overlay split -- tracks
 * the active board's real screen size directly (board_config.h, via gui.h). */
#define LYRICS_BACKDROP_WIDTH BOARD_SCREEN_WIDTH
#define LYRICS_BACKDROP_HEIGHT BOARD_SCREEN_HEIGHT
#define LYRICS_BACKDROP_BLUR_RADIUS 5
#define LYRICS_BACKDROP_BLUR_PASSES 3
#define LYRICS_BACKDROP_DARKEN_NUM 9
#define LYRICS_BACKDROP_DARKEN_DEN 20
#define LYRICS_POOL_SIZE 20
/* Both side margins together. Scaled as one value, not twice 20: on the
 * 320px board the rounding differs and the fullscreen width must not move. */
#define LYRICS_ROW_MARGINS BOARD_SCALE_PX(40)
#define LYRICS_ROW_WIDTH (BOARD_SCREEN_WIDTH - LYRICS_ROW_MARGINS)
#define LYRICS_ROW_MIN_WIDTH BOARD_SCALE_PX(80)
#define LYRICS_ROW_GAP BOARD_SCALE_PX(24)
#define LYRICS_ACTIVE_LINE_ANCHOR_Y (lyrics_embedded ? BOARD_SCALE_PX(16) : (BOARD_SCREEN_HEIGHT / 4))
#define LYRICS_TOP_PAD LYRICS_ACTIVE_LINE_ANCHOR_Y
#define LYRICS_TIMER_PERIOD_MS 150
#define LYRICS_AUTO_FOLLOW_RESUME_MS 3000L
#define LYRICS_FONT_SIZE_OPTION_COUNT (sizeof(lyrics_font_size_options) / sizeof(lyrics_font_size_options[0]))

extern lv_font_t app_font_lyrics;
extern void enable_gesture_bubble_recursive(lv_obj_t * parent);
extern lv_obj_t * add_pill_row_base(lv_obj_t * parent, const char * text);
extern lv_color_t accent_lv_color(void);
extern void show_error_toast(const char * msg);
extern void gui_navigation_invalidate_font_snapshots(void);


extern lv_style_t style_theme_screen_bg;
extern lv_style_t style_theme_text_primary;
extern lv_style_t style_theme_text_secondary;
extern lv_style_t style_theme_row;
extern lv_style_t style_theme_text_muted;
extern lv_style_t style_theme_list_padding;
extern lv_style_t style_button_pressed;

extern void nav_push(lv_obj_t * screen);
extern void nav_pop(void);
extern void nav_reset_to_home(void);
extern void finalize_screen_navigation(lv_obj_t * screen);
extern void generic_back_cb(lv_event_t * e);

static lv_obj_t * lyrics_screen;
/* ---- Fullscreen lyrics view state -- see build_lyrics_screen() and the
 * async .lrc load / backdrop generation just above poll_cover_decode()'s
 * own section. All declared here because the async load/poll functions and
 * the screen builder that creates the LVGL objects live in different parts
 * of this file. ---- */
static lyrics_doc_t current_lyrics_doc;
static bool current_lyrics_doc_valid = false;
static int current_lyrics_doc_for_index = -1; /* gui_player_get_playlist_index() current_lyrics_doc was loaded for */
static int current_lyrics_doc_generation = -1;
static int lyrics_load_generation = 0;
/* Embedded lyrics tags (ID3 USLT, FLAC/Opus LYRICS/
 * UNSYNCEDLYRICS, M4A "\xA9lyr") are usually plain unsynced text with no
 * [mm:ss.xx] timestamps. current_lyrics_doc_valid/current_lyrics_doc
 * stay reserved for the synced case (an .lrc sidecar, or tags containing
 * LRC timestamps); unsynced text is displayed as a static block without
 * per-line highlight or auto-follow, mutually exclusive with
 * current_lyrics_doc_valid. current_lyrics_plain_text is malloc'd, owned
 * by these globals once poll_lyrics_load() transfers it; freed on the next
 * load and whenever current_lyrics_plain_mode is cleared. */

typedef struct {
    uint8_t * cover_copy;
    int for_index;
    int lyrics_generation;
} lyrics_backdrop_request_t;

extern void audio_seek(double seconds);
extern double audio_get_position_seconds(void);

typedef struct {
    int generation;
    int for_index;
    char track_path[PATH_MAX];
} lyrics_load_request_t;
extern player_settings_t current_settings;
extern lv_font_t app_font_22;
extern void sync_player_topbar_visibility(lv_obj_t * screen);

bool current_lyrics_plain_mode = false;
static char * current_lyrics_plain_text = NULL;
static lv_obj_t * lyrics_backdrop_img;
static lv_obj_t * lyrics_list;
static lv_obj_t * lyrics_spacer;
static lv_obj_t * lyrics_empty_label;
static lv_obj_t * lyrics_plain_label; /* current_lyrics_plain_mode's own display -- see its own comment */
static lv_obj_t * lyrics_active_marker;
static lv_timer_t * lyrics_timer;
static bool lyrics_embedded = false;
/* Row width of the embedded pane (a layout's lyrics_area may be narrower than
 * the screen), reset when it is hidden, and the layout's look. */
static int32_t lyrics_embedded_row_width = LYRICS_ROW_WIDTH;
static bool lyrics_area_mode; /* embedded in a layout's own area */
/* A hidden prewarm keeps its content/geometry for a matching reveal. Track
 * changes may still rebuild the pool while hidden, but must not expose it. */
static bool lyrics_embedded_prepared_hidden;
static lv_obj_t * lyrics_prepared_parent;
static int32_t lyrics_prepared_width;
static bool lyrics_prepared_area_mode;
static gui_lyrics_look_t lyrics_look;
static bool lyrics_backdrop_discard_active = false;
static uint8_t * current_lyrics_backdrop_bytes;
static lv_image_dsc_t current_lyrics_backdrop_dsc;
static void launch_lyrics_backdrop_decode(void); /* defined alongside build_lyrics_screen() below -- see poll_cover_decode()'s own use of it */
static pthread_t lyrics_load_thread;
static bool lyrics_load_active = false;
/* atomic_bool ensures well-defined memory ordering between the worker
 * thread's write and the UI thread's poll read. */
static atomic_bool lyrics_load_done_flag = false;
static int lyrics_load_result_generation;
static int lyrics_load_result_for_index;
static bool lyrics_load_result_ok;
static lyrics_doc_t lyrics_load_result_doc;
/* Set alongside lyrics_load_result_ok when a source (sidecar or embedded
 * tag) had text but no [mm:ss.xx] timestamps to parse into lyrics_load_
 * result_doc -- see lyrics_load_thread_func()'s own comment. Mutually
 * exclusive with lyrics_load_result_ok: exactly one of the two, or neither
 * (no lyrics found anywhere), is ever true for a given load. Owned by the
 * worker thread until the done flag flips, same as lyrics_load_result_doc. */
static bool lyrics_load_result_plain_mode;
static char * lyrics_load_result_plain_text; /* malloc'd, only meaningful when lyrics_load_result_plain_mode */
/* Bumped on every launch_lyrics_load() call (both a real track change and
 * the internal pending-relaunch below) -- the identity a finished result is
 * checked against in poll_lyrics_load(), not gui_player_get_playlist_index(). gui_player_get_playlist_index()
 * is a numeric SLOT, not a track identity: if the whole playlist is
 * replaced (a different album/Subsonic queue/etc. loaded) while a load is
 * still in flight, the new playlist's own track at that same slot number
 * can easily be a completely different song, and an index-only check would
 * wrongly accept the stale result for it. A strictly increasing counter
 * has no such collision. */
static bool lyrics_load_pending_valid = false;
static int lyrics_load_pending_for_index;
static char lyrics_load_pending_path[PATH_MAX];
static void * lyrics_load_thread_func(void * arg) {
    lyrics_load_request_t * req = (lyrics_load_request_t *) arg;
    lyrics_doc_t doc;
    bool ok = lyrics_load_sidecar(req->track_path, &doc);
    bool plain_mode = false;
    char * plain_text = NULL;

    /* Fall back to the track's embedded lyrics tag (ID3 USLT, FLAC/Opus
     * LYRICS/UNSYNCEDLYRICS, M4A "\xA9lyr") when there is no .lrc sidecar.
     * Parses LRC timestamps if present; otherwise falls back to plain_mode
     * (static unsynced text). */
    if (!ok) {
        track_metadata_t meta;
        metadata_read_lyrics_without_artwork(req->track_path, &meta);
        if (meta.lyrics) {
            /* Keep embedded lyrics under the same byte limit as sidecars.
             * Apart from avoiding a large parser/UI allocation, bounded
             * length prevents strlen() from walking arbitrarily far through
             * a malformed decoder result. Oversized or empty tags behave as
             * no lyrics; metadata.lyrics remains owned here and is freed
             * below. */
            size_t lyrics_len = strnlen(meta.lyrics, LYRICS_MAX_FILE_BYTES + 1U);
            if (lyrics_len > 0 && lyrics_len <= LYRICS_MAX_FILE_BYTES) {
                if (lyrics_parse_buffer(meta.lyrics, lyrics_len, &doc)) {
                    ok = true;
                } else {
                    /* Only the unsynchronized/plain fallback is sanitized.
                     * Valid synced lyrics retain their parser behavior. */
                    utf8_sanitize(meta.lyrics);
                    plain_mode = true;
                    plain_text = meta.lyrics;
                    meta.lyrics = NULL; /* ownership transferred to plain_text -- don't free it below */
                }
            }
        }
        free(meta.picture_data);
        free(meta.lyrics);
    }

    lyrics_load_result_generation = req->generation;
    lyrics_load_result_for_index = req->for_index;
    lyrics_load_result_ok = ok;
    if (ok) lyrics_load_result_doc = doc;
    lyrics_load_result_plain_mode = plain_mode;
    lyrics_load_result_plain_text = plain_text;
    free(req);
    atomic_store_explicit(&lyrics_load_done_flag, true, memory_order_release); /* written last -- poll_lyrics_load() only checks this flag */
    return NULL;
}
static void launch_lyrics_load(int for_index, const char * track_path) {
    lyrics_load_generation++;
    if (lyrics_load_active) {
        lyrics_load_pending_for_index = for_index;
        snprintf(lyrics_load_pending_path, sizeof(lyrics_load_pending_path), "%s", track_path);
        lyrics_load_pending_valid = true;
        return;
    }

    lyrics_load_request_t * req = malloc(sizeof(*req));
    if (!req) return;
    req->generation = lyrics_load_generation;
    req->for_index = for_index;
    snprintf(req->track_path, sizeof(req->track_path), "%s", track_path);
    atomic_store_explicit(&lyrics_load_done_flag, false, memory_order_relaxed);
    lyrics_load_active = true;
    if (pthread_create(&lyrics_load_thread, NULL, lyrics_load_thread_func, req) != 0) {
        free(req);
        lyrics_load_active = false;
    }
}
/* Called every tick from update_timer_cb, same as poll_cover_decode() --
 * regardless of whether the lyrics screen is actually open, so a load
 * finishes well before the user ever taps the album art. Deliberately does
 * not touch any lyrics-screen LVGL object directly (unlike poll_cover_
 * decode(), which owns gui_player_get_cover_img()/player_overlay_panel outright) -- open_
 * lyrics_screen() and lyrics_timer_cb() below independently notice when
 * current_lyrics_doc_for_index no longer matches what the pool was last
 * built from and resync from scratch at that point, so there is exactly
 * one place that reconciles the parsed doc with the on-screen pool. */
static void poll_lyrics_load(void) {
    if (!lyrics_load_active || !atomic_load_explicit(&lyrics_load_done_flag, memory_order_acquire)) return;
    lyrics_load_active = false;
    pthread_join(lyrics_load_thread, NULL);

    if (lyrics_load_result_generation == lyrics_load_generation) {
        if (current_lyrics_doc_valid) lyrics_doc_free(&current_lyrics_doc);
        current_lyrics_doc_valid = lyrics_load_result_ok;
        if (lyrics_load_result_ok) current_lyrics_doc = lyrics_load_result_doc;
        current_lyrics_doc_for_index = lyrics_load_result_for_index;
        current_lyrics_doc_generation = lyrics_load_result_generation;

        free(current_lyrics_plain_text);
        current_lyrics_plain_mode = lyrics_load_result_plain_mode;
        current_lyrics_plain_text = lyrics_load_result_plain_text;

        if (current_lyrics_doc_valid || current_lyrics_plain_mode)
            launch_lyrics_backdrop_decode();
    } else {
        if (lyrics_load_result_ok) lyrics_doc_free(&lyrics_load_result_doc); /* stale -- superseded by a later launch before this landed */
        free(lyrics_load_result_plain_text);
    }

    if (lyrics_load_pending_valid) {
        lyrics_load_pending_valid = false;
        launch_lyrics_load(lyrics_load_pending_for_index, lyrics_load_pending_path);
    }
}
static pthread_t lyrics_backdrop_thread;
static bool lyrics_backdrop_active = false;
static atomic_bool lyrics_backdrop_done_flag = false; /* atomic_bool, not volatile -- see lyrics_load_done_flag's own doc comment */
static uint8_t * lyrics_backdrop_result_bytes;
static int lyrics_backdrop_result_for_index = -1;
static int lyrics_backdrop_result_generation = -1;
static int lyrics_backdrop_active_for_index = -1;
static int lyrics_backdrop_active_generation = -1;
static int current_lyrics_backdrop_for_index = -1;
static int current_lyrics_backdrop_generation = -1;
/* Blur the square cover to the display's fullscreen backdrop via the shared
 * frosted glass pipeline. Pure pixel math: safe on the backdrop worker thread. */
static uint8_t * compute_lyrics_backdrop_bytes(const uint8_t * cover_bytes) {
    return frosted_glass_blur_rgb565((const uint16_t *) cover_bytes,
                                     COVER_ART_WIDTH, COVER_ART_HEIGHT,
                                     LYRICS_BACKDROP_WIDTH, LYRICS_BACKDROP_HEIGHT,
                                     LYRICS_BACKDROP_BLUR_RADIUS, LYRICS_BACKDROP_BLUR_PASSES,
                                     LYRICS_BACKDROP_DARKEN_NUM, LYRICS_BACKDROP_DARKEN_DEN,
                                     false);
}
static void * lyrics_backdrop_thread_func(void * arg) {
    lyrics_backdrop_request_t * req = (lyrics_backdrop_request_t *) arg;
    uint64_t t0 = db_log_now_ms();
    lyrics_backdrop_result_bytes = compute_lyrics_backdrop_bytes(req->cover_copy);
    DB_LOG("LYRICS", "backdrop_compute_ms=%llu", (unsigned long long) (db_log_now_ms() - t0));
    lyrics_backdrop_result_for_index = req->for_index;
    lyrics_backdrop_result_generation = req->lyrics_generation;
    free(req->cover_copy);
    free(req);
    atomic_store_explicit(&lyrics_backdrop_done_flag, true, memory_order_release); /* written last, same contract as every other _done_flag in this file */
    return NULL;
}
/* Set by launch_lyrics_backdrop_decode() when a request arrives while a
 * generation is already running for a since-superseded track.
 * poll_lyrics_backdrop() checks this once the in-flight job lands and
 * immediately kicks off a fresh generation for the current track. */
static bool lyrics_backdrop_regenerate_pending = false;
/* No queuing beyond the single pending flag above (never more than one
 * generation queued behind the active one) -- unlike cover art's own
 * cover_decode_pending, a slightly-stale intermediate backdrop for a
 * moment isn't a visible correctness bug, and this is called far less
 * often (screen-open/track-change-while-open, not every track change).
 * Also skips if gui_player's decoded cover isn't ready yet (rare: tapped
 * during the brief cover-decode window). poll_cover_decode() notifies this
 * module once it becomes available, so that attempt is retried without
 * blocking the tap. */
static void launch_lyrics_backdrop_decode(void) {
    /* The player-hosted view reuses its existing background. Only generate
     * the legacy backdrop when that standalone screen is actually visible. */
    if (lyrics_embedded || lv_screen_active() != lyrics_screen) return;
    if (current_lyrics_doc_generation != lyrics_load_generation ||
        current_lyrics_doc_for_index != gui_player_get_playlist_index() ||
        (!current_lyrics_doc_valid && !current_lyrics_plain_mode)) return;
    if (current_lyrics_backdrop_for_index == gui_player_get_playlist_index() &&
        current_lyrics_backdrop_generation == lyrics_load_generation) return;
    if (lyrics_backdrop_active) {
        if (lyrics_backdrop_active_for_index == gui_player_get_playlist_index() &&
            lyrics_backdrop_active_generation == lyrics_load_generation) return;
        lyrics_backdrop_regenerate_pending = true;
        return;
    }
    lyrics_backdrop_request_t * req = malloc(sizeof(*req));
    if (!req) return;
    req->cover_copy = malloc((size_t) COVER_ART_WIDTH * COVER_ART_HEIGHT * 2);
    if (!req->cover_copy) { free(req); return; }
    req->for_index = gui_player_get_playlist_index();
    if (!gui_player_copy_cover_rgb565(req->for_index, req->cover_copy,
                                     (size_t) COVER_ART_WIDTH * COVER_ART_HEIGHT * 2)) {
        free(req->cover_copy);
        free(req);
        return;
    }
    req->lyrics_generation = lyrics_load_generation;

    atomic_store_explicit(&lyrics_backdrop_done_flag, false, memory_order_relaxed);
    lyrics_backdrop_active = true;
    lyrics_backdrop_discard_active = false;
    lyrics_backdrop_active_for_index = req->for_index;
    lyrics_backdrop_active_generation = req->lyrics_generation;
    if (pthread_create(&lyrics_backdrop_thread, NULL, lyrics_backdrop_thread_func, req) != 0) {
        free(req->cover_copy);
        free(req);
        lyrics_backdrop_active = false;
    }
}
/* Applies a finished backdrop generation to lyrics_backdrop_img -- called
 * from lyrics_timer_cb() (only ticking while the lyrics screen is open)
 * rather than update_timer_cb(), so it resolves within one 150 ms tick of
 * becoming ready instead of waiting up to 500 ms. Sets up lv_image_dsc_t
 * with LV_IMAGE_HEADER_MAGIC and RGB565 format for LVGL's bin decoder. */
static void poll_lyrics_backdrop(void) {
    if (!lyrics_backdrop_active || !atomic_load_explicit(&lyrics_backdrop_done_flag, memory_order_acquire)) return;
    lyrics_backdrop_active = false;
    pthread_join(lyrics_backdrop_thread, NULL);

    bool result_current = !lyrics_embedded && !lyrics_backdrop_discard_active &&
                          lyrics_backdrop_result_for_index == gui_player_get_playlist_index() &&
                          lyrics_backdrop_result_generation == lyrics_load_generation;
    if (lyrics_backdrop_result_bytes && result_current) { /* NULL = allocation failure -- keep whatever backdrop (or plain black) is already showing */
        free(current_lyrics_backdrop_bytes);
        current_lyrics_backdrop_bytes = lyrics_backdrop_result_bytes;
        lyrics_backdrop_result_bytes = NULL;
        current_lyrics_backdrop_for_index = lyrics_backdrop_result_for_index;
        current_lyrics_backdrop_generation = lyrics_backdrop_result_generation;

        memset(&current_lyrics_backdrop_dsc, 0, sizeof(current_lyrics_backdrop_dsc));
        current_lyrics_backdrop_dsc.header.magic = LV_IMAGE_HEADER_MAGIC;
        current_lyrics_backdrop_dsc.header.cf = LV_COLOR_FORMAT_RGB565;
        current_lyrics_backdrop_dsc.header.w = LYRICS_BACKDROP_WIDTH;
        current_lyrics_backdrop_dsc.header.h = LYRICS_BACKDROP_HEIGHT;
        current_lyrics_backdrop_dsc.header.stride = LYRICS_BACKDROP_WIDTH * 2;
        current_lyrics_backdrop_dsc.data = current_lyrics_backdrop_bytes;
        current_lyrics_backdrop_dsc.data_size = (uint32_t) LYRICS_BACKDROP_WIDTH * LYRICS_BACKDROP_HEIGHT * 2;
        lv_image_set_src(lyrics_backdrop_img, &current_lyrics_backdrop_dsc);
        if (lv_screen_active() == lyrics_screen)
            lv_obj_remove_flag(lyrics_backdrop_img, LV_OBJ_FLAG_HIDDEN);
    } else {
        free(lyrics_backdrop_result_bytes);
        lyrics_backdrop_result_bytes = NULL;
    }

    /* Checked regardless of the success/failure branch above -- see this
     * flag's own doc comment; a request that arrived while the job that
     * just landed was still running must not be lost either way. */
    if (lyrics_backdrop_regenerate_pending) {
        lyrics_backdrop_regenerate_pending = false;
        launch_lyrics_backdrop_decode();
    }
}
static void open_lyrics_screen(void); /* defined alongside build_lyrics_screen() below */
static lv_obj_t * lyrics_rows[LYRICS_POOL_SIZE];
/* Prefix positions for the current document: offsets[i] is row i's Y and
 * offsets[count] is the bottom after its final gap. Long lines can wrap to
 * an arbitrary number of visual lines (up to LYRICS_MAX_LINE_BYTES), so a
 * fixed "three lines ought to fit" stride still allowed real text to paint
 * into its neighbor. These two parallel tables (offsets and per-line
 * line_space) cost at most ~32KB for 4000 lines and make rendering, hit
 * mapping and auto-follow share the exact measured geometry. */
static lyrics_layout_t lyrics_layout;
static int lyrics_window_start = -1; /* index currently shown by lyrics_rows[0]; -1 forces the first update to actually run */
static int lyrics_pool_synced_for_index = -1; /* current_lyrics_doc_for_index the pool/spacer were last built from */
static int lyrics_pool_synced_generation = -1; /* current_lyrics_doc_generation the row pool was last synchronized from */
/* Layout validity is independent of the row pool: the pool is reset when
 * the list is reparented, while the measured offsets remain valid for the
 * same document and font. */
static int lyrics_layout_for_index = -1;
static int lyrics_layout_generation = -1;
static bool lyrics_layout_valid;
static bool lyrics_auto_follow = true;
static int lyrics_last_centered_index = -2; /* -2 = "never centered yet", distinct from -1 (a real "before the first line" position) */
static struct timespec lyrics_last_manual_scroll_at;
/* Only current_lyrics_doc_for_index == gui_player_get_playlist_index() counts as "this
 * doc is for the track actually playing" -- a load still in flight, one
 * that finished for a since-superseded track, or simply having no track
 * playing at all, are all "no active line" here, matching poll_lyrics_
 * load()'s own staleness check above. */
static int lyrics_current_active_index(void) {
    if (!current_lyrics_doc_valid || current_lyrics_doc_for_index != gui_player_get_playlist_index() || gui_player_get_playlist_index() < 0) return -1;
    return lyrics_find_line_at(&current_lyrics_doc, audio_get_position_seconds());
}
static int32_t lyrics_line_y(int index) {
    return lyrics_layout_y(&lyrics_layout, index);
}
static int32_t lyrics_line_height(int index) {
    return lyrics_layout_height(&lyrics_layout, index);
}
static int32_t lyrics_line_line_space(int index) {
    return lyrics_layout_line_space(&lyrics_layout, index);
}
static void lyrics_build_line_offsets(int32_t row_width) {
    lyrics_layout_build(&lyrics_layout, current_lyrics_doc_valid ? &current_lyrics_doc : NULL,
                        &app_font_lyrics, row_width, LYRICS_ROW_GAP, LYRICS_TOP_PAD);
}
/* Line width for a pane `pane_width` wide: the same side margins as the
 * fullscreen list, kept sane for a very narrow pane. */
static int32_t lyrics_row_width_for(int32_t pane_width) {
    int32_t width = pane_width - LYRICS_ROW_MARGINS;
    if (width < LYRICS_ROW_MIN_WIDTH) width = LYRICS_ROW_MIN_WIDTH;
    if (width > pane_width) width = pane_width;
    return width;
}
static int32_t lyrics_target_row_width(void) {
    return lyrics_embedded ? lyrics_embedded_row_width : LYRICS_ROW_WIDTH;
}
static int lyrics_first_line_at_y(int32_t y, int count) {
    return lyrics_layout_first_at_y(&lyrics_layout, y, count);
}
/* Ensure measured geometry matches the current document, font invalidation
 * epoch and list anchor. This deliberately has no row-pool or scroll side
 * effects so the player can pay the first measurement before its opening
 * animation starts. */
static void lyrics_ensure_layout_width(bool force_layout_rebuild, int32_t row_width) {
    int count = current_lyrics_doc_valid ? current_lyrics_doc.count : 0;
    /* lyrics_layout_build() calls lv_text_get_size() once per line -- real,
     * synchronous UI-thread cost that scales with document length. Its
     * validity is tracked separately from pool synchronization because
     * embedding reparents/resets the row pool without changing measured
     * geometry. Font changes explicitly force a rebuild even though the
     * document identity stays the same. The row width is part of the key:
     * wrapping depends on it, and the fullscreen list, the default embedded
     * pane and a layout's own area can differ. */
    if (force_layout_rebuild || !lyrics_layout_valid || lyrics_layout.row_width != row_width ||
        current_lyrics_doc_for_index != lyrics_layout_for_index ||
        current_lyrics_doc_generation != lyrics_layout_generation) {
        uint64_t t0 = db_log_now_ms();
        lyrics_build_line_offsets(row_width);
        lyrics_layout_for_index = current_lyrics_doc_for_index;
        lyrics_layout_generation = current_lyrics_doc_generation;
        lyrics_layout_valid = true;
        DB_LOG("LYRICS", "layout_build_ms=%llu lines=%d", (unsigned long long) (db_log_now_ms() - t0), count);
    } else if (lyrics_layout.top_pad != LYRICS_TOP_PAD) {
        /* The embedded and fullscreen lists use different top anchors.
         * Translate the cached prefix offsets instead of remeasuring each
         * line; the per-line heights and wrap measurements are unchanged. */
        int32_t delta = LYRICS_TOP_PAD - lyrics_layout.top_pad;
        if (lyrics_layout.offsets) {
            for (int i = 0; i <= lyrics_layout.count; i++) lyrics_layout.offsets[i] += delta;
        }
        lyrics_layout.top_pad = LYRICS_TOP_PAD;
    }
}
static void lyrics_ensure_layout(bool force_layout_rebuild) {
    lyrics_ensure_layout_width(force_layout_rebuild, lyrics_target_row_width());
}
/* Re-syncs the row pool/spacer/empty-state to whatever current_lyrics_doc
 * currently holds -- called on every open (open_lyrics_screen() below) and
 * whenever lyrics_timer_cb() notices the doc changed while already open
 * (a track change while the user is looking at this screen). Always resets
 * scroll to the top and re-enables auto-follow, so both a fresh open and a
 * new track start from the same, predictable state rather than wherever a
 * previous track's manual scroll happened to leave it.
 *
 * force_layout_rebuild: gui_lyrics_refresh_layout() (font size / custom font
 * changed) must pass true -- see lyrics_ensure_layout() for the cache key. */
static void lyrics_reset_pool(bool force_layout_rebuild) {
    if (lyrics_active_marker) lv_obj_add_flag(lyrics_active_marker, LV_OBJ_FLAG_HIDDEN);
    int count = current_lyrics_doc_valid ? current_lyrics_doc.count : 0;
    lyrics_ensure_layout(force_layout_rebuild);

    /* current_lyrics_plain_mode -- see its own doc comment: a single static
     * text block, no per-line pool/highlight/auto-follow at all. Handled as
     * its own branch, entirely separate from the synced count==0/count>0
     * cases below, since "0 synced lines" (count==0) still needs the
     * "No synchronized lyrics found" empty state when plain mode ISN'T
     * active either (genuinely no lyrics anywhere). */
    if (current_lyrics_plain_mode && current_lyrics_plain_text) {
        lv_obj_add_flag(lyrics_empty_label, LV_OBJ_FLAG_HIDDEN);
        for (int slot = 0; slot < LYRICS_POOL_SIZE; slot++) lv_obj_add_flag(lyrics_rows[slot], LV_OBJ_FLAG_HIDDEN);
        lv_label_set_text(lyrics_plain_label, current_lyrics_plain_text);
        lv_obj_set_y(lyrics_plain_label, LYRICS_TOP_PAD);
        lv_obj_remove_flag(lyrics_plain_label, LV_OBJ_FLAG_HIDDEN);

        /* LV_LABEL_LONG_WRAP's real rendered height depends on the text
         * just set and isn't known until a layout pass runs -- unlike the
         * synced case's fixed per-line stride, this can't be computed from
         * a line count. lv_obj_update_layout() forces that pass immediately
         * so lv_obj_get_height() below reflects the real wrapped height,
         * not a stale one from whatever text was showing before. */
        lv_obj_update_layout(lyrics_plain_label);
        int32_t total_height = LYRICS_TOP_PAD + lv_obj_get_height(lyrics_plain_label) + LYRICS_TOP_PAD;
        lv_obj_set_pos(lyrics_spacer, 0, total_height > 0 ? total_height - 1 : 0);
    } else {
        lv_obj_add_flag(lyrics_plain_label, LV_OBJ_FLAG_HIDDEN);

        if (count == 0) {
            lv_obj_remove_flag(lyrics_empty_label, LV_OBJ_FLAG_HIDDEN);
            for (int slot = 0; slot < LYRICS_POOL_SIZE; slot++) lv_obj_add_flag(lyrics_rows[slot], LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(lyrics_empty_label, LV_OBJ_FLAG_HIDDEN);
        }

        int32_t total_height = count > 0 ? lyrics_line_y(count) + LYRICS_TOP_PAD : LYRICS_TOP_PAD;
        lv_obj_set_pos(lyrics_spacer, 0, total_height > 0 ? total_height - 1 : 0);
    }

    lv_obj_scroll_to_y(lyrics_list, 0, LV_ANIM_OFF);
    lyrics_window_start = -1;
    lyrics_pool_synced_for_index = current_lyrics_doc_for_index;
    lyrics_pool_synced_generation = current_lyrics_doc_generation;
    lyrics_auto_follow = true;
    lyrics_last_centered_index = -2;
    if (lyrics_embedded_prepared_hidden) {
        lv_obj_add_flag(lyrics_list, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(lyrics_empty_label, LV_OBJ_FLAG_HIDDEN);
    }
}
/* Repositions/relabels the row pool to cover the range of lines actually
 * scrolled into (or near) view, and recolors every visible row for the
 * current active_index -- called on every scroll event and every lyrics_
 * timer_cb() tick. Unlike compact_list_update_window(), this can't early-
 * return purely on "the window hasn't moved": the active line's highlight
 * can change (playback advancing) with the view sitting perfectly still. */
static void lyrics_update_window(int active_index) {
    int count = current_lyrics_doc_valid ? current_lyrics_doc.count : 0;
    if (count == 0) return; /* nothing to position -- empty state already shown by lyrics_reset_pool() */

    int32_t scroll_y = lv_obj_get_scroll_y(lyrics_list);
    if (scroll_y < 0) scroll_y = 0;
    int first = lyrics_first_line_at_y(scroll_y, count) - LYRICS_POOL_SIZE / 4;
    if (first < 0) first = 0;
    int max_first = count - LYRICS_POOL_SIZE;
    if (max_first < 0) max_first = 0;
    if (first > max_first) first = max_first;

    bool window_moved = first != lyrics_window_start;
    if (window_moved) lyrics_window_start = first;

    if (lyrics_active_marker) {
        bool show = lyrics_embedded && !lyrics_embedded_prepared_hidden &&
                    lyrics_area_mode && lyrics_look.active_marker &&
                    active_index >= first && active_index < first + LYRICS_POOL_SIZE && active_index < count;
        if (show) {
            int32_t row_x = lv_obj_get_x(lyrics_rows[0]);
            lv_obj_set_pos(lyrics_active_marker, row_x - BOARD_SCALE_PX(10), lyrics_line_y(active_index));
            lv_obj_set_size(lyrics_active_marker, BOARD_SCALE_PX(3), lyrics_line_height(active_index));
            lv_obj_set_style_bg_color(lyrics_active_marker, accent_lv_color(), 0);
            lv_obj_remove_flag(lyrics_active_marker, LV_OBJ_FLAG_HIDDEN);
        } else lv_obj_add_flag(lyrics_active_marker, LV_OBJ_FLAG_HIDDEN);
    }

    for (int slot = 0; slot < LYRICS_POOL_SIZE; slot++) {
        int index = first + slot;
        lv_obj_t * row = lyrics_rows[slot];
        if (index >= count) {
            lv_obj_add_flag(row, LV_OBJ_FLAG_HIDDEN);
            continue;
        }
        lv_obj_remove_flag(row, LV_OBJ_FLAG_HIDDEN);
        if (window_moved) {
            lv_obj_set_y(row, lyrics_line_y(index));
            lv_obj_set_height(row, lyrics_line_height(index));
            lv_obj_set_style_text_line_space(row, lyrics_line_line_space(index), 0);
            lv_label_set_text(row, current_lyrics_doc.lines[index].text);
        }
        lv_color_t active = lyrics_embedded && lyrics_look.has_active ? lyrics_look.active : accent_lv_color();
        lv_color_t normal = lyrics_embedded && lyrics_look.has_normal ? lyrics_look.normal : lv_color_make(150, 150, 150);
        lv_obj_set_style_text_color(row, index == active_index ? active : normal, 0);
    }
}
/* Tap a line to seek playback to it -- pool_slot (this row's fixed slot in
 * lyrics_rows[], passed as the event's user_data, same (void *)(intptr_t)
 * idiom plugin_interval_timer_cb uses elsewhere in this file) plus lyrics_
 * window_start resolves to the actual doc line index, same as compact_
 * list_row_click_cb()'s own index resolution. Re-enables auto-follow (in
 * case it was suspended) and forces an immediate recenter on the next
 * lyrics_timer_cb() tick, so the view snaps straight to the tapped line
 * and keeps following from there rather than leaving the old scroll
 * position sitting stale until audio_get_position_seconds() catches up. */
static void lyrics_row_click_cb(lv_event_t * e) {
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    int slot = (int) (intptr_t) lv_event_get_user_data(e);
    int index = lyrics_window_start + slot;
    if (!current_lyrics_doc_valid || index < 0 || index >= current_lyrics_doc.count) return;

    audio_seek(current_lyrics_doc.lines[index].time_ms / 1000.0);
    lyrics_auto_follow = true;
    lyrics_last_centered_index = -2;
}
/* A tap that lands on the pane itself rather than on a line: a layout's own
 * lyrics area uses it to close the lyrics. Lines handle their own taps and
 * do not bubble them. */
static void lyrics_list_click_cb(lv_event_t * e) {
    if (lv_event_get_code(e) != LV_EVENT_CLICKED || lv_event_get_target(e) != lyrics_list) return;
    void (*on_empty_tap)(void) = lyrics_embedded && lyrics_area_mode ? lyrics_look.on_empty_tap : NULL;
    if (on_empty_tap) on_empty_tap();
}
/* Shared shutdown for every way out of this screen (manual swipe-back below,
 * and lyrics_timer_cb()'s own auto-close when a track change resolves to no
 * lyrics) -- pauses the timer and drops the backdrop before nav_pop().
 * Real bug caught in review: the backdrop (~768KB RGB565, LYRICS_BACKDROP_
 * WIDTH x HEIGHT x 2) stayed allocated for the rest of the app's runtime
 * after leaving this screen -- not a leak (poll_lyrics_backdrop() already
 * frees the previous one before replacing it on the NEXT open), but a
 * needless standing hold on a device with ~56MB total RAM. Freed here
 * instead. lyrics_backdrop_img is re-hidden so a stale freed pointer in
 * current_lyrics_backdrop_dsc can't get redrawn before the next open's own
 * launch_lyrics_backdrop_decode() lands a fresh one -- open_lyrics_screen()
 * already falls back to a plain dark background for that brief window
 * regardless (see launch_lyrics_backdrop_decode()'s own comment), so this
 * costs nothing new on re-entry beyond that already-accepted, already-
 * documented gap. */
void gui_lyrics_prepare_exit(void) {
    lv_timer_pause(lyrics_timer);
    lv_obj_add_flag(lyrics_backdrop_img, LV_OBJ_FLAG_HIDDEN);
}

static void close_lyrics_screen(void) {
    gui_lyrics_prepare_exit();
    nav_pop();
}

/* The auto-close-on-track-change-with-no-lyrics path (lyrics_timer_cb())
 * still calls close_lyrics_screen() directly. A user's own right-swipe now
 * goes through gui_shell.c's live back-swipe instead (reveal-style, exiting
 * to Player) once that candidate claims the press -- see gui_shell_back_
 * swipe_owns_press()'s own comment for why standing down here, not just
 * wait_release() at gesture-recognition time, is what actually prevents
 * double-handling on real hardware. */
static void lyrics_gesture_event_cb(lv_event_t * e) {
    if (lyrics_embedded) return;
    if (lv_event_get_code(e) != LV_EVENT_GESTURE) return;
    lv_indev_t * indev = lv_indev_active();
    if (!indev || lv_indev_get_gesture_dir(indev) != LV_DIR_RIGHT) return;
    if (gui_shell_back_swipe_owns_press()) return;

    lv_indev_wait_release(indev); /* same reasoning as screen_gesture_event_cb's own comment -- avoid a phantom tap landing on the player screen under the still-down finger */
    close_lyrics_screen();
}
/* Records a manual scroll only when driven by an actual finger-press (same
 * lv_indev_get_state()==LV_INDEV_STATE_PRESSED precedent used elsewhere in
 * this file), not the programmatic lv_obj_scroll_to_y() call lyrics_timer_
 * cb() itself makes to re-center on the active line -- otherwise every
 * auto-follow re-center would immediately look like a manual scroll and
 * suspend itself. */
static void lyrics_scroll_event_cb(lv_event_t * e) {
    (void) e;
    lv_indev_t * indev = lv_indev_active();
    if (indev && lv_indev_get_state(indev) == LV_INDEV_STATE_PRESSED) {
        lyrics_auto_follow = false;
        clock_gettime(CLOCK_MONOTONIC, &lyrics_last_manual_scroll_at);
    }
    lyrics_update_window(lyrics_current_active_index());
}
static void lyrics_timer_update(bool animate_scroll) {
    launch_lyrics_backdrop_decode();
    poll_lyrics_backdrop();

    if (current_lyrics_doc_for_index != lyrics_pool_synced_for_index ||
        current_lyrics_doc_generation != lyrics_pool_synced_generation) {
        /* current_lyrics_doc_for_index changes synchronously the moment the
         * track changes (gui_lyrics_load_track()), well before the
         * background .lrc/tag load (poll_lyrics_load(), on gui.c's own
         * slower 500ms poll) has had a chance to resolve -- gui_lyrics_load_
         * track() clears current_lyrics_doc_valid/current_lyrics_plain_mode
         * to false right away too, so judging "no lyrics" on that momentary
         * state would misjudge a track that does have lyrics, and -- since
         * lyrics_pool_synced_for_index would already match by the time the
         * real result lands -- never get a second chance to display them.
         * Wait until the load actually resolves (or confirm none was
         * needed at all, e.g. a remote track: launch_lyrics_load() then
         * never runs and lyrics_load_generation is left unbumped) before
         * deciding anything. */
        if (current_lyrics_doc_generation != lyrics_load_generation) return;

        if (!lyrics_embedded && !current_lyrics_doc_valid && !current_lyrics_plain_mode) {
            /* The song this screen was showing lyrics for changed (manual
             * skip or natural end-of-track advance) and the new one has
             * none -- close back out instead of sitting on the "No
             * synchronized lyrics found" placeholder for a track the user
             * never asked to view lyrics for. open_lyrics_screen() already
             * pre-syncs lyrics_pool_synced_for_index before this timer's
             * first tick, so this branch only ever fires for a genuine
             * track change while already open, never the initial open of a
             * track that already has no lyrics (that case still shows the
             * placeholder, unchanged).
             *
             * Real bug caught in cross-check: close_lyrics_screen() calls
             * nav_pop(), which does a REAL stack decrement and its own
             * screen_transition_slide(). A user's live back-swipe (still
             * being dragged, gui_shell.c's back_swipe_tracking) already has
             * slide_transition_active set, so that nested transition would
             * return NULL and fall back to an immediate lv_screen_load()
             * out from under the still-live-dragged overlay -- and the
             * back-swipe's own nav_pop_stack_only() at release would then
             * double-decrement the stack (commit) or strand a
             * paused/hidden Lyrics screen that's no longer even on the
             * stack (cancel). Defer instead: the condition above isn't
             * consumed by this early return, so it retries every tick
             * until the gesture resolves and this fires cleanly. */
            if (gui_navigation_transition_in_progress()) return;
            close_lyrics_screen();
            return;
        }

        lyrics_reset_pool(false); /* index/generation already known to differ -- rebuild happens via that check */
        launch_lyrics_backdrop_decode(); /* track changed while this screen is open -- refresh the backdrop too */
    }

    /* current_lyrics_plain_mode -- see its own doc comment: a static text
     * block has no active line to track, no auto-follow-with-playback to
     * suspend/resume, and no per-line pool to reposition. lyrics_reset_
     * pool() above already did everything this screen needs for it. */
    if (current_lyrics_plain_mode) return;

    bool was_auto_follow = lyrics_auto_follow;
    lv_indev_t * indev = lv_indev_active();
    bool pressed = indev && lv_indev_get_state(indev) == LV_INDEV_STATE_PRESSED;
    if (pressed) {
        lyrics_auto_follow = false;
    } else if (!lyrics_auto_follow) {
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        long idle_ms = (now.tv_sec - lyrics_last_manual_scroll_at.tv_sec) * 1000L +
                       (now.tv_nsec - lyrics_last_manual_scroll_at.tv_nsec) / 1000000L;
        if (idle_ms >= LYRICS_AUTO_FOLLOW_RESUME_MS) lyrics_auto_follow = true;
    }
    /* Auto-follow just resumed after being suspended -- force a recenter
     * below even if active_index hasn't changed since the view may have
     * drifted away from it while suspended. */
    if (lyrics_auto_follow && !was_auto_follow) lyrics_last_centered_index = -2;

    int active_index = lyrics_current_active_index();

    if (lyrics_auto_follow && active_index >= 0 && active_index != lyrics_last_centered_index) {
        int32_t target = lyrics_line_y(active_index) - LYRICS_ACTIVE_LINE_ANCHOR_Y;
        if (target < 0) target = 0;
        lv_obj_scroll_to_y(lyrics_list, target, animate_scroll ? LV_ANIM_ON : LV_ANIM_OFF);
        lyrics_last_centered_index = active_index;
    }

    lyrics_update_window(active_index);
}
static void lyrics_timer_cb(lv_timer_t * timer) {
    (void) timer;
    lyrics_timer_update(true);
}
static void open_lyrics_screen(void) {
    gui_lyrics_hide_embedded();
    lv_obj_remove_flag(lyrics_list, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(lyrics_backdrop_img, LV_OBJ_FLAG_HIDDEN);
    launch_lyrics_backdrop_decode();
    if (current_lyrics_backdrop_bytes &&
        current_lyrics_backdrop_for_index == gui_player_get_playlist_index() &&
        current_lyrics_backdrop_generation == lyrics_load_generation)
        lv_obj_remove_flag(lyrics_backdrop_img, LV_OBJ_FLAG_HIDDEN);
    lyrics_reset_pool(false);
    lv_timer_resume(lyrics_timer);
    nav_push(lyrics_screen);
    lyrics_timer_cb(NULL); /* one immediate tick so the view isn't blank for up to LYRICS_TIMER_PERIOD_MS after opening */
}

/* Row width, position and text alignment follow the pane they sit in. */
static void lyrics_apply_row_geometry(int32_t pane_width, int32_t row_width, lv_text_align_t align) {
    int32_t x = (pane_width - row_width) / 2;
    for (int slot = 0; slot < LYRICS_POOL_SIZE; slot++) {
        lv_obj_set_width(lyrics_rows[slot], row_width);
        lv_obj_set_x(lyrics_rows[slot], x);
        lv_obj_set_style_text_align(lyrics_rows[slot], align, 0);
    }
    lv_obj_set_width(lyrics_plain_label, row_width);
    lv_obj_set_x(lyrics_plain_label, x);
    lv_obj_set_style_text_align(lyrics_plain_label, align, 0);
}

void gui_lyrics_set_look(const gui_lyrics_look_t * look) {
    if (look) lyrics_look = *look;
    else memset(&lyrics_look, 0, sizeof(lyrics_look));
}

void gui_lyrics_prepare_layout_for_width(int32_t width) {
    lyrics_ensure_layout_width(false, lyrics_row_width_for(width));
}

static void lyrics_apply_embedded_geometry(lv_obj_t * parent, int32_t x, int32_t y,
                                           int32_t w, int32_t h, bool area_mode,
                                           bool rows_prepared) {
    lyrics_embedded = true;
    lyrics_area_mode = area_mode;
    lyrics_embedded_row_width = lyrics_row_width_for(w);
    if (!rows_prepared) {
        lyrics_apply_row_geometry(w, lyrics_embedded_row_width,
                                  area_mode && lyrics_look.has_align ? lyrics_look.align : LV_TEXT_ALIGN_CENTER);
        /* Empty and plain lyrics need the same contrast as synchronized lines. */
        lv_obj_set_style_text_color(lyrics_empty_label, lyrics_look.has_normal ? lyrics_look.normal : lv_color_hex(0xc8c8c8), 0);
        lv_obj_set_style_text_color(lyrics_plain_label, lyrics_look.has_normal ? lyrics_look.normal : lv_color_hex(0xe6e6e6), 0);
        lyrics_backdrop_discard_active = lyrics_backdrop_active;
        lyrics_backdrop_regenerate_pending = false;
        lv_obj_add_flag(lyrics_backdrop_img, LV_OBJ_FLAG_HIDDEN);
        lv_obj_set_parent(lyrics_list, parent);
        lv_obj_set_parent(lyrics_empty_label, parent);
    }
    /* Its 90% width is relative to the parent, the whole screen; a layout's
     * area may be narrower, so size it to the pane there. */
    if (area_mode) lv_obj_set_width(lyrics_empty_label, w * 9 / 10);
    lv_obj_align(lyrics_list, LV_ALIGN_TOP_LEFT, x, y);
    lv_obj_set_size(lyrics_list, w, h);
    /* Align to the list's center so parent height/padding do not shift the
     * empty state outside the requested region. */
    lv_obj_update_layout(lyrics_list);
    if (area_mode) {
        /* A short area: keep the message inside it, ending in an ellipsis.
         * Measured from its natural wrapped height each time it is shown. */
        lv_label_set_long_mode(lyrics_empty_label, LV_LABEL_LONG_WRAP);
        lv_obj_set_height(lyrics_empty_label, LV_SIZE_CONTENT);
        lv_obj_update_layout(lyrics_empty_label);
        if (lv_obj_get_height(lyrics_empty_label) > h) {
            lv_label_set_long_mode(lyrics_empty_label, LV_LABEL_LONG_DOT);
            lv_obj_set_height(lyrics_empty_label, h);
        }
    }
    lv_obj_align_to(lyrics_empty_label, lyrics_list, LV_ALIGN_CENTER, 0, 0);
}

static bool lyrics_embedded_preparation_matches(lv_obj_t * parent, int32_t w,
                                                bool area_mode) {
    return lyrics_embedded_prepared_hidden && lyrics_prepared_parent == parent &&
           lyrics_prepared_width == w && lyrics_prepared_area_mode == area_mode;
}

static void lyrics_prepare_embedded_hidden(lv_obj_t * parent, int32_t x, int32_t y,
                                           int32_t w, int32_t h, bool area_mode) {
    if (!parent || !lyrics_screen || h <= 0 || w <= 0) return;
    lyrics_embedded_prepared_hidden = true;
    lyrics_prepared_parent = parent;
    lyrics_prepared_width = w;
    lyrics_prepared_area_mode = area_mode;
    lv_timer_pause(lyrics_timer);
    lv_obj_add_flag(lyrics_list, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(lyrics_empty_label, LV_OBJ_FLAG_HIDDEN);
    if (lyrics_active_marker) lv_obj_add_flag(lyrics_active_marker, LV_OBJ_FLAG_HIDDEN);
    lyrics_apply_embedded_geometry(parent, x, y, w, h, area_mode, false);
    /* Build visible rows and center the active line without starting an
     * LVGL scroll animation on an object that is still hidden. */
    lyrics_reset_pool(false);
    lyrics_timer_update(false);
}

static void lyrics_show_embedded(lv_obj_t * parent, int32_t x, int32_t y,
                                 int32_t w, int32_t h, bool area_mode) {
    if (!parent || !lyrics_screen || h <= 0 || w <= 0) return;
    bool prepared = lyrics_embedded_preparation_matches(parent, w, area_mode);
    if (!prepared) {
        /* Direct/non-animated callers use the same no-scroll preparation
         * path, then reveal it synchronously. */
        lyrics_prepare_embedded_hidden(parent, x, y, w, h, area_mode);
        prepared = lyrics_embedded_preparation_matches(parent, w, area_mode);
        if (!prepared) return;
    } else {
        /* Timeline endpoints can change pane height/position without changing
         * row wrapping. Reapply only the cheap rectangle setup, retaining the
         * prepared content and row pool. */
        bool height_changed = lv_obj_get_height(lyrics_list) != h;
        lyrics_apply_embedded_geometry(parent, x, y, w, h, area_mode, true);
        /* Preparation can use a taller pane. Recenter against the final
         * scroll bounds without restarting a visible scroll animation. */
        if (height_changed) lyrics_last_centered_index = -2;
        lyrics_timer_update(false);
    }
    lyrics_embedded_prepared_hidden = false;
    lv_obj_remove_flag(lyrics_list, LV_OBJ_FLAG_HIDDEN);
    bool show_empty = !current_lyrics_plain_mode &&
                      (!current_lyrics_doc_valid || current_lyrics_doc.count == 0);
    if (show_empty)
        lv_obj_remove_flag(lyrics_empty_label, LV_OBJ_FLAG_HIDDEN);
    else
        lv_obj_add_flag(lyrics_empty_label, LV_OBJ_FLAG_HIDDEN);
    lyrics_update_window(lyrics_current_active_index());
    lv_timer_resume(lyrics_timer);
}

void gui_lyrics_show_embedded(lv_obj_t * parent, int32_t top, int32_t height) {
    lyrics_show_embedded(parent, 0, top, BOARD_SCREEN_WIDTH, height, false);
}

void gui_lyrics_show_embedded_area(lv_obj_t * parent, int32_t x, int32_t y, int32_t w, int32_t h) {
    lyrics_show_embedded(parent, x, y, w, h, true);
}

void gui_lyrics_prepare_embedded(lv_obj_t * parent, int32_t x, int32_t y,
                                int32_t width, int32_t height, bool area_mode) {
    /* Populate and lay out the rows before the player starts moving. Keep
     * both sibling objects hidden and the timer paused until reveal. */
    lyrics_prepare_embedded_hidden(parent, x, y, width, height, area_mode);
}

void gui_lyrics_hide_embedded(void) {
    if (!lyrics_embedded) return;
    lyrics_embedded_prepared_hidden = false;
    lyrics_prepared_parent = NULL;
    lyrics_prepared_width = 0;
    lyrics_prepared_area_mode = false;
    lv_timer_pause(lyrics_timer);
    lv_obj_add_flag(lyrics_list, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(lyrics_empty_label, LV_OBJ_FLAG_HIDDEN);
    lv_obj_set_parent(lyrics_list, lyrics_screen);
    lv_obj_set_parent(lyrics_empty_label, lyrics_screen);
    lv_obj_set_size(lyrics_list, LYRICS_BACKDROP_WIDTH, LYRICS_BACKDROP_HEIGHT);
    lv_obj_align(lyrics_list, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_set_width(lyrics_empty_label, lv_pct(90));
    lv_obj_set_height(lyrics_empty_label, LV_SIZE_CONTENT);
    lv_label_set_long_mode(lyrics_empty_label, LV_LABEL_LONG_WRAP);
    lv_obj_center(lyrics_empty_label);
    lyrics_embedded = false;
    lyrics_area_mode = false;
    lv_obj_set_style_text_color(lyrics_empty_label, lv_color_hex(0xc8c8c8), 0);
    lv_obj_set_style_text_color(lyrics_plain_label, lv_color_hex(0xe6e6e6), 0);
    if (lyrics_active_marker) lv_obj_add_flag(lyrics_active_marker, LV_OBJ_FLAG_HIDDEN);
    lyrics_embedded_row_width = LYRICS_ROW_WIDTH;
    lyrics_apply_row_geometry(LYRICS_BACKDROP_WIDTH, LYRICS_ROW_WIDTH, LV_TEXT_ALIGN_CENTER);
    /* Fullscreen open restores visibility and reconciles the row pool. The
     * measured line geometry is independent of this list's parent/anchor. */
}
static lv_obj_t * build_lyrics_screen(void) {
    lv_obj_t * scr = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(scr, lv_color_make(0, 0, 0), 0);
    lv_obj_remove_flag(scr, LV_OBJ_FLAG_SCROLLABLE);

    lyrics_backdrop_img = lv_image_create(scr);
    lv_obj_set_size(lyrics_backdrop_img, LYRICS_BACKDROP_WIDTH, LYRICS_BACKDROP_HEIGHT);
    lv_obj_align(lyrics_backdrop_img, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_add_flag(lyrics_backdrop_img, LV_OBJ_FLAG_HIDDEN); /* shown by poll_lyrics_backdrop() once a real backdrop exists */
    lv_obj_remove_flag(lyrics_backdrop_img, LV_OBJ_FLAG_CLICKABLE);

    /* Kept as a transparent stacking/click-through layer for layout
     * compatibility. Darkness is baked into the backdrop before its final
     * dithered RGB565 conversion; alpha-blending black here would quantize
     * it a second time and recreate visible color bands. */
    lv_obj_t * dark_overlay = lv_obj_create(scr);
    lv_obj_set_size(dark_overlay, LYRICS_BACKDROP_WIDTH, LYRICS_BACKDROP_HEIGHT);
    lv_obj_align(dark_overlay, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_set_style_bg_color(dark_overlay, lv_color_make(0, 0, 0), 0);
    lv_obj_set_style_bg_opa(dark_overlay, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(dark_overlay, 0, 0);
    lv_obj_set_style_radius(dark_overlay, 0, 0);
    lv_obj_remove_flag(dark_overlay, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_remove_flag(dark_overlay, LV_OBJ_FLAG_CLICKABLE);

    lyrics_empty_label = lv_label_create(scr);
    lv_label_set_text(lyrics_empty_label, TR("No synchronized lyrics found"));
    lv_obj_set_style_text_font(lyrics_empty_label, &app_font_22, 0);
    lv_obj_set_style_text_color(lyrics_empty_label, lv_color_make(200, 200, 200), 0);
    /* app_font_22 is one of the size-tier-swappable app_font_* handles (see
     * fallback_font_apply_size_tier()'s own comment) -- at the largest tier
     * this string's natural single-line width exceeds the screen, and with
     * no width/wrap set here it just ran off both edges instead of
     * wrapping (GitHub issue #91). Bounded width + centered wrap keeps it
     * fully visible at every tier. */
    lv_obj_set_width(lyrics_empty_label, lv_pct(90));
    lv_label_set_long_mode(lyrics_empty_label, LV_LABEL_LONG_WRAP);
    lv_obj_set_style_text_align(lyrics_empty_label, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_center(lyrics_empty_label);
    lv_obj_add_flag(lyrics_empty_label, LV_OBJ_FLAG_HIDDEN);
    lv_obj_remove_flag(lyrics_empty_label, LV_OBJ_FLAG_CLICKABLE);

    /* The scrollable content object itself -- transparent so the backdrop/
     * overlay behind it show through. The pooled row labels below each get
     * their own LV_EVENT_CLICKED handler (lyrics_row_click_cb -- tap a
     * line to seek to it); this object only listens for LV_EVENT_SCROLL,
     * to track manual-scroll-vs-auto-follow. */
    lyrics_list = lv_obj_create(scr);
    lv_obj_set_size(lyrics_list, LYRICS_BACKDROP_WIDTH, LYRICS_BACKDROP_HEIGHT);
    lv_obj_align(lyrics_list, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_set_style_bg_opa(lyrics_list, 0, 0);
    lv_obj_set_style_border_width(lyrics_list, 0, 0);
    lv_obj_set_style_radius(lyrics_list, 0, 0);
    lv_obj_set_style_pad_all(lyrics_list, 0, 0);
    lv_obj_set_scroll_dir(lyrics_list, LV_DIR_VER);
    lv_obj_set_scrollbar_mode(lyrics_list, LV_SCROLLBAR_MODE_OFF);

    for (int slot = 0; slot < LYRICS_POOL_SIZE; slot++) {
        lv_obj_t * row = lv_label_create(lyrics_list);
        lv_obj_set_width(row, LYRICS_ROW_WIDTH);
        lv_obj_set_height(row, lv_font_get_line_height(&app_font_lyrics));
        lv_label_set_long_mode(row, LV_LABEL_LONG_WRAP);
        lv_obj_set_style_text_align(row, LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_style_text_font(row, &app_font_lyrics, 0); /* own separate size, not app_font_28 -- see fallback_font.h */
        lv_obj_remove_flag(row, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_pos(row, BOARD_SCALE_PX(20), LYRICS_TOP_PAD);
        lv_obj_add_flag(row, LV_OBJ_FLAG_HIDDEN); /* shown by lyrics_update_window() once it has real content */
        lv_obj_add_flag(row, LV_OBJ_FLAG_CLICKABLE); /* tap to seek -- lyrics_row_click_cb() */
        lv_obj_add_event_cb(row, lyrics_row_click_cb, LV_EVENT_CLICKED, (void *) (intptr_t) slot);
        lyrics_rows[slot] = row;
    }

    lyrics_active_marker = lv_obj_create(lyrics_list);
    lv_obj_remove_style_all(lyrics_active_marker);
    lv_obj_set_style_bg_opa(lyrics_active_marker, LV_OPA_COVER, 0);
    lv_obj_remove_flag(lyrics_active_marker, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(lyrics_active_marker, LV_OBJ_FLAG_HIDDEN);

    /* current_lyrics_plain_mode's own display -- a single wrapped label
     * showing the whole embedded-tag text as a static block (no per-line
     * highlight, no auto-follow-with-playback), for the common case where
     * an embedded lyrics tag has no [mm:ss.xx] timestamps to drive the
     * synced view above. Plain LVGL scrolling on lyrics_list (already
     * scrollable) is enough here -- unlike the synced rows, there's no
     * windowing/virtualization needed for a single object. */
    lyrics_plain_label = lv_label_create(lyrics_list);
    lv_obj_set_width(lyrics_plain_label, LYRICS_ROW_WIDTH);
    lv_label_set_long_mode(lyrics_plain_label, LV_LABEL_LONG_WRAP);
    lv_obj_set_style_text_align(lyrics_plain_label, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_text_font(lyrics_plain_label, &app_font_lyrics, 0);
    lv_obj_set_style_text_color(lyrics_plain_label, lv_color_make(230, 230, 230), 0);
    lv_obj_remove_flag(lyrics_plain_label, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_remove_flag(lyrics_plain_label, LV_OBJ_FLAG_CLICKABLE); /* static text -- no tap-to-seek, there's no timing to seek to */
    lv_obj_set_pos(lyrics_plain_label, BOARD_SCALE_PX(20), LYRICS_TOP_PAD);
    lv_obj_add_flag(lyrics_plain_label, LV_OBJ_FLAG_HIDDEN); /* shown by lyrics_reset_pool() when current_lyrics_plain_mode */

    /* 1x1 invisible spacer at the bottom of the FULL virtual list -- not
     * hidden (a hidden object doesn't count toward scrollable content
     * size), just visually imperceptible. Same technique as compact_list's
     * own spacer (screen_builders.c). */
    lyrics_spacer = lv_obj_create(lyrics_list);
    lv_obj_set_size(lyrics_spacer, 1, 1);
    lv_obj_set_style_bg_opa(lyrics_spacer, 0, 0);
    lv_obj_set_style_border_width(lyrics_spacer, 0, 0);
    lv_obj_remove_flag(lyrics_spacer, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_remove_flag(lyrics_spacer, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_pos(lyrics_spacer, 0, 0);

    lv_obj_add_event_cb(lyrics_list, lyrics_scroll_event_cb, LV_EVENT_SCROLL, NULL);
    lv_obj_add_event_cb(lyrics_list, lyrics_list_click_cb, LV_EVENT_CLICKED, NULL);

    /* Right-swipe-to-exit -- see lyrics_gesture_event_cb()'s own doc
     * comment for why this is a dedicated handler rather than finalize_
     * screen_navigation()'s shared one. Attached to scr (not lyrics_list)
     * and bubbled up the same way finalize_screen_navigation() does for
     * every other screen, via enable_gesture_bubble_recursive() -- a drag
     * starting on lyrics_list (or one of its pooled row labels) still needs
     * to reach this handler once LVGL judges it a horizontal gesture rather
     * than a vertical scroll. */
    lv_obj_add_flag(scr, LV_OBJ_FLAG_CLICKABLE);
    enable_gesture_bubble_recursive(scr);
    lv_obj_add_event_cb(scr, lyrics_gesture_event_cb, LV_EVENT_GESTURE, NULL);

    /* Created paused -- only ticks while this screen is actually open
     * (resumed by open_lyrics_screen(), paused by lyrics_gesture_event_cb()),
     * so it costs nothing the rest of the time. Not the existing 500 ms
     * update_timer_cb: that one must keep running at its own cadence
     * regardless of whether this screen is open, and 150 ms is needed here
     * for a scroll/highlight cadence that actually looks smooth. */
    lyrics_timer = lv_timer_create(lyrics_timer_cb, LYRICS_TIMER_PERIOD_MS, NULL);
    lv_timer_pause(lyrics_timer);

    return scr;
}
static const lyrics_font_size_option_t lyrics_font_size_options[] = {
    { 1, N_("Medium") }, { 2, N_("Large") },
};
static lv_obj_t * lyrics_font_size_screen;
static lv_obj_t * lyrics_font_size_list;
static void lyrics_font_size_option_row_cb(lv_event_t * e);
static void populate_lyrics_font_size_screen(void) {
    lv_obj_clean(lyrics_font_size_list);
    for (size_t i = 0; i < LYRICS_FONT_SIZE_OPTION_COUNT; i++) {
        bool selected = current_settings.lyrics_font_size_tier == lyrics_font_size_options[i].tier;
        add_pill_option_row(lyrics_font_size_list, TR(lyrics_font_size_options[i].label),
                            selected, lyrics_font_size_option_row_cb, (void *) (intptr_t) i);
    }
}
/* Live-apply, same black-mask-behind-a-one-shot-timer shape as the general
 * Font Size selector (font_size_option_row_cb()/font_size_apply_timer_cb(),
 * gui_network.c) -- no more "Restart Now?" popup/real reboot. Deliberately
 * lighter than that one's own post-apply refresh: app_font_lyrics is
 * consumed exclusively by this screen's own row pool (gui_lyrics_refresh_
 * layout() already resyncs it, including live descender-free row heights,
 * pixel-perfect), so there's no Settings-pill-row geometry or nav-stack
 * sweep to do here, unlike a general Font Size change. */
static void lyrics_font_size_apply_timer_cb(lv_timer_t * timer) {
    lv_obj_t * mask = (lv_obj_t *) lv_timer_get_user_data(timer);
    int target = (int) (intptr_t) lv_obj_get_user_data(mask) - 1;
    lv_timer_delete(timer);
    if (!fallback_font_apply_lyrics_size_tier(target)) {
        lv_obj_delete(mask);
        show_error_toast(TR("Could not apply lyrics text size"));
        return;
    }

    gui_navigation_invalidate_font_snapshots();
    current_settings.lyrics_font_size_tier = target;
    settings_save(&current_settings);
    gui_lyrics_refresh_layout();
    populate_lyrics_font_size_screen();

    lv_obj_delete(mask);
}

static void lyrics_font_size_option_row_cb(lv_event_t * e) {
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    int index = (int) (intptr_t) lv_event_get_user_data(e);
    int target = lyrics_font_size_options[index].tier;
    if (target == current_settings.lyrics_font_size_tier) return;

    lv_obj_t * mask = lv_obj_create(lv_layer_sys());
    lv_obj_set_user_data(mask, (void *) (intptr_t) (target + 1));
    lv_display_t * display = lv_display_get_default();
    lv_obj_set_size(mask,
                    lv_display_get_horizontal_resolution(display),
                    lv_display_get_vertical_resolution(display));
    lv_obj_align(mask, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(mask, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(mask, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(mask, 0, 0);
    lv_obj_set_style_radius(mask, 0, 0);
    lv_obj_set_style_pad_all(mask, 0, 0);
    lv_obj_remove_flag(mask, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(mask, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_move_foreground(mask);
    lv_obj_invalidate(mask);

    /* Leave enough time for the normal refresh timer to paint the mask;
     * synchronous lv_refr_now() here would re-enter rendering from an input
     * callback -- see font_size_option_row_cb()'s own matching comment
     * (gui_network.c) for why. */
    lv_timer_create(lyrics_font_size_apply_timer_cb, 35, mask);
}
static lv_obj_t * build_lyrics_font_size_screen(void) {
    lv_obj_t * title_label; /* unused after build -- title never changes */
    return build_subsonic_list_screen(TR("Lyrics Text Size"), &title_label, &lyrics_font_size_list);
}
static void open_lyrics_font_size_screen(void) {
    populate_lyrics_font_size_screen();
    nav_push(lyrics_font_size_screen);
}
void lyrics_font_size_settings_row_cb(lv_event_t * e) {
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    open_lyrics_font_size_screen();
}


extern void player_transition_mark_dirty(void);
extern bool audio_is_playing(void);
extern const char * asset_path(const char * name);

void gui_lyrics_init(void) {
    lyrics_screen = build_lyrics_screen();
    lyrics_font_size_screen = build_lyrics_font_size_screen();
}

/* For gui_reload.c's in-process UI reload -- deletes both screens this
 * module owns so gui_lyrics_init() can rebuild them from a clean slate
 * without leaking the old objects. */
void gui_lyrics_teardown(void) {
    gui_lyrics_hide_embedded();
    /* Unguarded lv_timer_create() at this screen's own build site -- same
     * leaked-old-timer hazard as gui_player_teardown()'s volume_popup_hide_
     * timer, see its own comment. */
    if (lyrics_timer) { lv_timer_del(lyrics_timer); lyrics_timer = NULL; }
    if (lyrics_screen) { lv_obj_delete(lyrics_screen); lyrics_screen = NULL; }
    lyrics_active_marker = NULL;
    if (lyrics_font_size_screen) { lv_obj_delete(lyrics_font_size_screen); lyrics_font_size_screen = NULL; }
}

lv_obj_t * gui_lyrics_get_screen(void) {
    return lyrics_screen;
}

void gui_lyrics_poll_load(void) {
    if (gui_player_lyrics_animation_in_progress()) return;
    poll_lyrics_load();
}

void gui_lyrics_poll_backdrop(void) {
    if (gui_player_lyrics_animation_in_progress()) return;
    poll_lyrics_backdrop();
}

void gui_lyrics_on_cover_changed(int current_playlist_index) {
    if (current_lyrics_doc_generation == lyrics_load_generation &&
        current_lyrics_doc_for_index == current_playlist_index &&
        (current_lyrics_doc_valid || current_lyrics_plain_mode)) {
        launch_lyrics_backdrop_decode();
    }
}

void gui_lyrics_load_track(int index, const char * path) {
    if (current_lyrics_doc_valid) {
        lyrics_doc_free(&current_lyrics_doc);
        current_lyrics_doc_valid = false;
    }
    if (current_lyrics_plain_mode) {
        free(current_lyrics_plain_text);
        current_lyrics_plain_text = NULL;
        current_lyrics_plain_mode = false;
    }
    current_lyrics_doc_for_index = index;
    if (path) launch_lyrics_load(index, path);
    else {
        /* Invalidate an in-flight local load when switching to a track
         * without a local lyrics source, including the same queue slot. */
        lyrics_load_pending_valid = false;
        current_lyrics_doc_generation = ++lyrics_load_generation;
    }
    if (lyrics_embedded) lyrics_reset_pool(true);
}

void gui_lyrics_open_screen(void) {
    open_lyrics_screen();
}

bool gui_lyrics_has_background_work(void) {
    return lyrics_load_active || lyrics_backdrop_active;
}

void gui_lyrics_cancel_background_work(void) {
    lyrics_load_generation++;
    if (lyrics_load_active) {
        pthread_join(lyrics_load_thread, NULL);
        lyrics_load_active = false;
    }
    if (lyrics_backdrop_active) {
        pthread_join(lyrics_backdrop_thread, NULL);
        lyrics_backdrop_active = false;
    }
}

void gui_lyrics_refresh_layout(void) {
    if (!lyrics_screen) return;
    /* Called after something that changes lv_text_get_size()'s own results
     * for the SAME document (lyrics text size, custom font) -- the document
     * identity (index/generation) is unchanged, so lyrics_reset_pool()'s own
     * skip-if-unsynced check would otherwise wrongly keep the layout table
     * measured against the old font. Force it. */
    lyrics_reset_pool(true);
    if (!lv_obj_has_flag(lyrics_screen, LV_OBJ_FLAG_HIDDEN)) {
        lv_obj_invalidate(lyrics_screen);
    }
}

void gui_lyrics_prepare_layout(void) {
    lyrics_ensure_layout(false);
}
