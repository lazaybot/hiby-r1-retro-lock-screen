#include "gui_navigation.h"
#include "gui_setup.h"
#include "gui.h"
#include "gui_theme.h"
#include "gui_notifications.h"
#include "gui_library.h"
#include "gui_queue.h"
#include "gui_player.h"
#include "gui_plugins.h"
#include "gui_settings.h"
#include "gui_network.h"
#include "gui_lyrics.h"
#include "gui_shell.h"
#include "gui_books.h"
#include "gui_lock_screen.h"
#include "gui_text_input.h"
#include "gui_text_view.h"
#include "screen_builders.h"
#include "metadata.h"
#include "audio.h"
#include "settings.h"
#include "assets.h"
#include "device_config.h"
#include "transition_compositor.h"
#include "db_log.h"

static lv_obj_t * nav_stack[NAV_STACK_MAX] = { NULL };
static int nav_depth = 0;
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern player_settings_t current_settings;

/* A callback can chain through an intermediate screen and push another
 * text-entry prompt before the old text-entry slot is removed. Cancel only
 * when the shared text-entry screen no longer exists anywhere in the stack. */
static void cancel_text_input_if_unstacked(lv_obj_t * removed_screen) {
    if (removed_screen != gui_text_input_get_screen()) return;
    for (int i = 0; i < nav_depth; i++) {
        if (nav_stack[i] == removed_screen) return;
    }
    gui_text_input_cancel_if_removed(removed_screen);
}

extern lv_obj_t * gui_shell_get_home_screen();

extern lv_obj_t * gui_library_get_music_screen();
extern lv_obj_t * stream_media_screen;
extern lv_obj_t * gui_network_get_wireless_screen();
extern lv_obj_t * gui_shell_get_dac_home_screen();
extern lv_obj_t * gui_player_get_screen();
extern lv_obj_t * gui_settings_get_about_screen();
extern lv_obj_t * gui_settings_get_screen();
extern lv_obj_t * gui_settings_get_system_screen();

extern void sync_player_topbar_visibility(lv_obj_t * screen);
extern void open_quick_drawer(void);
extern void close_quick_drawer(void);
extern bool point_in_swipe_dead_zone(lv_point_t p);
extern bool active_press_is_over_drag_adjust_widget(void);


/* Forward navigation slides the current screen out to the left as the new
 * one slides in from the right (matching a left-swipe gesture); back
 * navigation is the mirror of that. */
#define NAV_ANIM_TIME_MS 120 /* Short settle; input feedback precedes movement. */

/* Slide transitions use pre-rendered RGB565 bitmaps rather than animating
 * the live widget trees. Two static snapshots (one per screen) are blitted
 * per frame instead of re-rendering both widget trees, then the real target
 * screen is made active once the slide finishes. */

/* Forward declarations so build_flattened_transition_frame() (below) can
 * reference these, which is defined before the actual variable definitions
 * further down the file. */

/* Alpha-blends one row of an ARGB8888 source over an RGB565 destination
 * row, `count` pixels wide -- shared by build_flattened_transition_frame()
 * below for compositing a persistent lv_layer_top() band (status bar,
 * home indicator) onto a screen-only RGB565 base. LVGL's ARGB8888 memory
 * layout is B,G,R,A per pixel (see lv_color32_t in lv_color.h), not the
 * A,R,G,B its name suggests. */
static void blend_argb8888_row_over_rgb565(uint16_t * dst, const uint8_t * src_argb, int32_t count) {
    for (int32_t x = 0; x < count; x++) {
        uint8_t b = src_argb[x * 4 + 0];
        uint8_t g = src_argb[x * 4 + 1];
        uint8_t r = src_argb[x * 4 + 2];
        uint8_t a = src_argb[x * 4 + 3];
        if (a == 0) continue; /* fully transparent -- leave the destination pixel untouched */
        if (a == 255) {
            dst[x] = (uint16_t) (((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
            continue;
        }
        uint16_t old = dst[x];
        uint8_t old_r = (uint8_t) (((old >> 11) & 0x1F) << 3);
        uint8_t old_g = (uint8_t) (((old >> 5) & 0x3F) << 2);
        uint8_t old_b = (uint8_t) ((old & 0x1F) << 3);
        uint8_t nr = (uint8_t) (((uint32_t) r * a + (uint32_t) old_r * (255 - a)) / 255);
        uint8_t ng = (uint8_t) (((uint32_t) g * a + (uint32_t) old_g * (255 - a)) / 255);
        uint8_t nb = (uint8_t) (((uint32_t) b * a + (uint32_t) old_b * (255 - a)) / 255);
        dst[x] = (uint16_t) (((nr >> 3) << 11) | ((ng >> 2) << 5) | (nb >> 3));
    }
}

/* Snapshots `overlay_obj` (an lv_layer_top() child -- status_bar_band or
 * home_indicator_band, never a whole layer, see build_flattened_transition_
 * frame()'s own comment on why) as ARGB8888 and alpha-blends it onto
 * `base` at overlay_obj's own real on-screen coordinates. No-op (leaves
 * base untouched) if the snapshot itself fails -- caller still gets a
 * usable, if incomplete, frame rather than none at all. */
static void blend_overlay_onto_base(lv_draw_buf_t * base, lv_obj_t * overlay_obj) {
    lv_area_t coords;
    lv_obj_get_coords(overlay_obj, &coords);
    int32_t ow = lv_area_get_width(&coords);
    int32_t oh = lv_area_get_height(&coords);
    if (ow <= 0 || oh <= 0) return;

    lv_draw_buf_t * overlay = lv_snapshot_take(overlay_obj, LV_COLOR_FORMAT_ARGB8888);
    if (!overlay) return;

    int32_t base_w = (int32_t) base->header.w;
    int32_t base_h = (int32_t) base->header.h;
    for (int32_t y = 0; y < oh; y++) {
        int32_t dy = coords.y1 + y;
        if (dy < 0 || dy >= base_h) continue;
        int32_t dx0 = coords.x1;
        int32_t count = ow;
        int32_t sx0 = 0;
        if (dx0 < 0) { sx0 = -dx0; count += dx0; dx0 = 0; }
        if (dx0 + count > base_w) count = base_w - dx0;
        if (count <= 0) continue;
        const uint8_t * srow = (const uint8_t *) lv_draw_buf_goto_xy(overlay, (uint32_t) sx0, (uint32_t) y);
        uint16_t * drow = (uint16_t *) lv_draw_buf_goto_xy(base, (uint32_t) dx0, (uint32_t) dy);
        blend_argb8888_row_over_rgb565(drow, srow, count);
    }
    lv_draw_buf_destroy(overlay);
}

/* Screen-only RGB565 base for target_screen -- player_dismiss_btn's hidden
 * flag (Player's own standalone back arrow, part of gui_player_get_screen()'s own
 * subtree, not a separate layer) is temporarily forced to its TARGET-state
 * value (based on current_settings.hide_player_topbar, never on whichever
 * live screen happens to be active right now) before snapshotting, then
 * restored immediately after -- safe because nothing here ever yields to a
 * real lv_timer_handler()/lv_refr_now() refresh pass in between, so the
 * live UI never actually renders the temporary state to the real screen.
 * Deliberately does NOT include the persistent status bar / home-indicator
 * content -- see blend_persistent_bars() below for why that's kept
 * separate rather than baked in here. Caller owns the returned buffer;
 * returns NULL on snapshot failure. */
static lv_draw_buf_t * snapshot_screen_base(lv_obj_t * target_screen) {
    if (!target_screen) return NULL;

    lv_obj_t * dismiss_btn = gui_player_get_dismiss_btn();
    bool dismiss_target_hidden = current_settings.hide_player_topbar && target_screen == gui_player_get_screen();
    bool dismiss_touched = (dismiss_btn != NULL && target_screen == gui_player_get_screen());
    bool dismiss_was_hidden = false;
    if (dismiss_touched) {
        dismiss_was_hidden = lv_obj_has_flag(dismiss_btn, LV_OBJ_FLAG_HIDDEN);
        if (dismiss_target_hidden) lv_obj_add_flag(dismiss_btn, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_remove_flag(dismiss_btn, LV_OBJ_FLAG_HIDDEN);
    }

    lv_draw_buf_t * base = lv_snapshot_take(target_screen, LV_COLOR_FORMAT_RGB565);

    if (dismiss_touched) {
        if (dismiss_was_hidden) lv_obj_add_flag(dismiss_btn, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_remove_flag(dismiss_btn, LV_OBJ_FLAG_HIDDEN);
    }
    return base;
}

/* Blends whichever persistent lv_layer_top() bands would actually be
 * visible on target_screen (status_bar_band per Settings > Display > "Hide
 * Player/Lyrics Top Bar", home_indicator_band per Settings > Display >
 * "Swipe Up for Home") onto an existing owned RGB565 base, mutating it in
 * place. Kept as a separate, fresh step from the base snapshot itself
 * (snapshot_screen_base() above) so a cached base does not bake in stale
 * clock, battery, wifi, or home-indicator content.
 * Persistent bars are blended fresh at transition time to reflect current
 * status. Only the two named, permanent bands are composited in (avoiding
 * transient overlays on lv_layer_top()). status_bar_band and
 * home_indicator_band hidden flags are temporarily set to match target
 * screen expectations during blending. */
static void blend_persistent_bars(lv_draw_buf_t * base, lv_obj_t * target_screen) {
    bool topbar_target_hidden = current_settings.hide_player_topbar &&
                                 (target_screen == gui_player_get_screen() || target_screen == gui_lyrics_get_screen());
    lv_obj_t * sb = gui_shell_get_status_bar_band();
    lv_obj_t * hb = gui_shell_get_home_indicator_band();
    if (sb) {
        bool status_was_hidden = lv_obj_has_flag(sb, LV_OBJ_FLAG_HIDDEN);
        if (!topbar_target_hidden) {
            if (status_was_hidden) lv_obj_remove_flag(sb, LV_OBJ_FLAG_HIDDEN);
            gui_shell_set_status_bar_screen_context(target_screen);
            blend_overlay_onto_base(base, sb);
        }
        gui_shell_set_status_bar_screen_context(lv_screen_active());
        if (status_was_hidden) lv_obj_add_flag(sb, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_remove_flag(sb, LV_OBJ_FLAG_HIDDEN);
    }
    /* Home is already the gesture's destination, so showing its pill there
     * adds a dead-looking bottom bar with no navigation value. Lyrics also
     * deliberately disables the gesture. Keep target-screen snapshots in
     * lockstep with the live visibility policy below. */
    bool home_indicator_target_visible = current_settings.swipe_up_home_enabled &&
                                         target_screen != gui_shell_get_home_screen() &&
                                         target_screen != gui_lyrics_get_screen();
    if (hb && home_indicator_target_visible) {
        bool home_was_hidden = lv_obj_has_flag(hb, LV_OBJ_FLAG_HIDDEN);
        if (home_was_hidden) lv_obj_remove_flag(hb, LV_OBJ_FLAG_HIDDEN);
        blend_overlay_onto_base(base, hb);
        if (home_was_hidden) lv_obj_add_flag(hb, LV_OBJ_FLAG_HIDDEN);
    }
}

/* Builds a complete, opaque, full-screen RGB565 frame representing exactly
 * what the display should look like once target_screen is the active
 * screen -- a fresh screen-only base (snapshot_screen_base()) with the
 * persistent bars blended fresh on top (blend_persistent_bars()). Used as
 * begin_slide_transition()'s synchronous fallback when neither the static-
 * screen cache nor the Phase 2 player cache has a base available -- the
 * cached-base cases dup their own cached base and call
 * blend_persistent_bars() directly instead of going through this, so the
 * bars are still always fresh even when the (comparatively expensive)
 * screen content itself comes from a cache. Caller owns the returned
 * buffer (lv_draw_buf_destroy() it when done); returns NULL on allocation/
 * snapshot failure. */
static lv_draw_buf_t * build_flattened_transition_frame(lv_obj_t * target_screen) {
    lv_draw_buf_t * base = snapshot_screen_base(target_screen);
    if (!base) return NULL;
    blend_persistent_bars(base, target_screen);
    return base;
}

/* A deliberately narrow set of screens are pure static content -- fixed
 * icon-grid/pill-list items baked in at build time, no toggles, no
 * per-item state, nothing a timer ever touches. Their screen-only content
 * is rendered ONCE at startup and reused forever, since re-rendering it
 * before every single visit was the last remaining cost in an otherwise-
 * cheap transition -- the persistent status bar/home-indicator content is
 * deliberately NOT part of this cached base (see blend_persistent_bars()'s
 * own comment on why baking bars into a cache built once at startup goes
 * stale); begin_slide_transition() blends them in fresh every time it uses
 * this cache. Anything with actual dynamic content (player screen, file/
 * song lists, Settings' toggles, the accent-color picker's selection ring,
 * Subsonic status screens) is deliberately left out of THIS particular
 * cache -- the player screen has its own dedicated cache
 * (player_transition_cache_buf below), and whatever screen a nav_push()
 * most recently left behind has its own single-slot cache too
 * (back_target_cache_buf, further below); anything else genuinely is
 * rendered fresh on every transition. */
#define STATIC_SNAPSHOT_SCREEN_COUNT 9
static lv_obj_t * static_snapshot_screen[STATIC_SNAPSHOT_SCREEN_COUNT];
static lv_draw_buf_t * static_snapshot_buf[STATIC_SNAPSHOT_SCREEN_COUNT];
static uint64_t static_snapshot_scroll_state[STATIC_SNAPSHOT_SCREEN_COUNT];

/* Static screen content can still contain scrollable containers. Include
 * every descendant's scroll offsets in the cache key so a screen cached at
 * its initial position is never reused after the user has scrolled it. */
static uint64_t static_snapshot_scroll_state_recursive(lv_obj_t * obj, uint64_t hash) {
    hash ^= (uint32_t) lv_obj_get_scroll_x(obj);
    hash *= UINT64_C(1099511628211);
    uint32_t scroll_y = (uint32_t) lv_obj_get_scroll_y(obj);
    hash ^= scroll_y;
    hash *= UINT64_C(1099511628211);
    uint32_t child_count = lv_obj_get_child_count(obj);
    hash ^= child_count;
    hash *= UINT64_C(1099511628211);
    for (uint32_t i = 0; i < child_count; i++) {
        hash = static_snapshot_scroll_state_recursive(lv_obj_get_child(obj, (int32_t) i), hash);
    }
    return hash;
}

static uint64_t static_snapshot_scroll_state_for(lv_obj_t * scr) {
    return scr ? static_snapshot_scroll_state_recursive(scr, UINT64_C(14695981039346656037)) : 0;
}

static lv_draw_buf_t * get_static_snapshot(lv_obj_t * scr) {
    for (int i = 0; i < STATIC_SNAPSHOT_SCREEN_COUNT; i++) {
        if (static_snapshot_screen[i] != scr) continue;
        if (static_snapshot_buf[i] &&
            static_snapshot_scroll_state[i] != static_snapshot_scroll_state_for(scr)) {
            /* Transitions always dup a cached base before using it, so this
             * cache-owned buffer is not aliased by an in-flight transition. */
            lv_draw_buf_destroy(static_snapshot_buf[i]);
            static_snapshot_buf[i] = NULL;
        }
        return static_snapshot_buf[i];
    }
    return NULL;
}

/* Refresh a scrolled menu while idle, so returning to it does not need
 * to render its entire widget tree in the navigation callback. */
static void static_scroll_snapshot_async(void * data) {
    int index = (int) (intptr_t) data;
    if (gui_navigation_transition_in_progress() || index < 0 ||
        index >= STATIC_SNAPSHOT_SCREEN_COUNT) return;
    for (lv_indev_t * indev = lv_indev_get_next(NULL); indev; indev = lv_indev_get_next(indev)) {
        if (lv_indev_get_type(indev) == LV_INDEV_TYPE_POINTER &&
            lv_indev_get_state(indev) == LV_INDEV_STATE_PRESSED) return;
    }
    lv_obj_t * screen = static_snapshot_screen[index];
    if (!screen) return;
    uint64_t scroll = static_snapshot_scroll_state_for(screen);
    if (static_snapshot_buf[index] && static_snapshot_scroll_state[index] == scroll) return;
    lv_draw_buf_t * fresh = snapshot_screen_base(screen);
    if (!fresh) return;
    if (static_snapshot_buf[index]) lv_draw_buf_destroy(static_snapshot_buf[index]);
    static_snapshot_buf[index] = fresh;
    static_snapshot_scroll_state[index] = scroll;
}

static void static_scroll_end_cb(lv_event_t * event) {
    lv_async_call(static_scroll_snapshot_async, lv_event_get_user_data(event));
}

static void register_static_scroll_callbacks(lv_obj_t * obj, int index) {
    void * data = (void *) (intptr_t) index;
    lv_obj_remove_event_cb_with_user_data(obj, static_scroll_end_cb, data);
    if (lv_obj_has_flag(obj, LV_OBJ_FLAG_SCROLLABLE))
        lv_obj_add_event_cb(obj, static_scroll_end_cb, LV_EVENT_SCROLL_END, data);
    for (uint32_t i = 0; i < lv_obj_get_child_count(obj); ++i)
        register_static_scroll_callbacks(lv_obj_get_child(obj, (int32_t) i), index);
}

void register_static_snapshot(int index, lv_obj_t * scr) {
    if (index < 0 || index >= STATIC_SNAPSHOT_SCREEN_COUNT || !scr) return;
    register_static_scroll_callbacks(scr, index);
    /* Destroy any buffer from a prior registration of this slot first -- see
     * gui_navigation_invalidate_font_snapshots()'s own destroy-before-
     * overwrite pattern just below. Without this, re-registering the same
     * slot (e.g. gui_navigation_init() running again after a UI reload)
     * leaks the previous lv_draw_buf_t. */
    if (static_snapshot_buf[index]) lv_draw_buf_destroy(static_snapshot_buf[index]);
    static_snapshot_screen[index] = scr;
    static_snapshot_buf[index] = snapshot_screen_base(scr);
    static_snapshot_scroll_state[index] = static_snapshot_scroll_state_for(scr);
}

static void player_transition_discard_cache(void);
static void back_target_cache_discard(void);

static void rebuild_font_snapshots_async_cb(void * unused) {
    (void) unused;
    for (int i = 0; i < STATIC_SNAPSHOT_SCREEN_COUNT; i++) {
        if (!static_snapshot_screen[i]) continue;
        screen_builders_refresh_font_geometry(static_snapshot_screen[i]);
        if (static_snapshot_buf[i]) lv_draw_buf_destroy(static_snapshot_buf[i]);
        static_snapshot_buf[i] = snapshot_screen_base(static_snapshot_screen[i]);
        static_snapshot_scroll_state[i] = static_snapshot_scroll_state_for(static_snapshot_screen[i]);
    }
}

void gui_navigation_invalidate_font_snapshots(void) {
    /* Destroy first: until the next settled LVGL pass rebuilds these, every
     * transition falls back to a fresh render and can never expose an old-
     * font bitmap.  The rebuild is one-shot, restoring the normal cached
     * transition cost before the user can navigate after the black mask. */
    for (int i = 0; i < STATIC_SNAPSHOT_SCREEN_COUNT; i++) {
        if (static_snapshot_buf[i]) lv_draw_buf_destroy(static_snapshot_buf[i]);
        static_snapshot_buf[i] = NULL;
    }
    player_transition_discard_cache();
    back_target_cache_discard();
    lv_async_call(rebuild_font_snapshots_async_cb, NULL);
}

static void rebuild_theme_snapshots_async_cb(void * unused) {
    (void) unused;
    for (int i = 0; i < STATIC_SNAPSHOT_SCREEN_COUNT; i++) {
        if (static_snapshot_screen[i] && !static_snapshot_buf[i]) {
            static_snapshot_buf[i] = snapshot_screen_base(static_snapshot_screen[i]);
            static_snapshot_scroll_state[i] = static_snapshot_scroll_state_for(static_snapshot_screen[i]);
        }
    }
}

void gui_navigation_invalidate_theme_snapshots(void) {
    for (int i = 0; i < STATIC_SNAPSHOT_SCREEN_COUNT; i++) {
        if (static_snapshot_buf[i]) lv_draw_buf_destroy(static_snapshot_buf[i]);
        static_snapshot_buf[i] = NULL;
    }
    player_transition_discard_cache();
    back_target_cache_discard();
    lv_async_call(rebuild_theme_snapshots_async_cb, NULL);
}

/* Player-screen transition-frame cache. gui_player_get_screen() is dynamic
 * (track metadata/art/play-state), so it cannot be baked in once like the
 * static snapshots above. An independent owned copy is rebuilt asynchronously
 * via lv_async_call() when track art finishes decoding, on play/pause icon
 * changes, on accent-color changes, and when the hide-topbar setting changes
 * -- NOT on per-second progress-bar ticks. The cached frame's progress fill
 * may be a few seconds stale; this is intentional. Always safe to use:
 * this copy is never aliased to any live widget memory.
 * Screen-only base -- persistent bars blended in fresh at transition time. */
static lv_draw_buf_t * player_transition_cache_buf = NULL;
static bool player_transition_cache_dirty = true;

static void player_transition_discard_cache(void) {
    if (player_transition_cache_buf) lv_draw_buf_destroy(player_transition_cache_buf);
    player_transition_cache_buf = NULL;
    player_transition_cache_dirty = true;
    if (gui_player_get_screen()) lv_async_call(player_transition_cache_async_cb, NULL);
}

bool player_transition_cache_is_dirty(void) { return player_transition_cache_dirty; }

static void player_transition_rebuild_cache(void) {
    /* The source remains active until the slide completes, so the active-
     * screen check alone still allows a costly snapshot during entry.
     * Keep dirty set; the screen-handoff sync retries when Player is offscreen. */
    if (gui_navigation_transition_in_progress()) return;
    /* Nothing to gain while gui_player_get_screen() is already the live screen --
     * no transition can ever target the screen already on display, and
     * re-snapshotting it here would just be wasted work on every one of
     * its own dynamic updates (track change, progress tick via the other
     * dirty triggers, etc.) while the user is actually looking at it. */
    if (!gui_player_get_screen() || lv_screen_active() == gui_player_get_screen()) return;
#ifdef UI_PERF_TRACE
    uint64_t perf_start_us = ui_perf_now_us();
#endif
    lv_draw_buf_t * fresh = snapshot_screen_base(gui_player_get_screen());
    if (!fresh) return; /* OOM -- keep whatever's cached (stale beats nothing); still tried again on the next dirty notification */
    if (player_transition_cache_buf) lv_draw_buf_destroy(player_transition_cache_buf);
    player_transition_cache_buf = fresh;
    player_transition_cache_dirty = false;
#ifdef UI_PERF_TRACE
    printf("PERF player_cache rebuild_us=%llu\n", (unsigned long long) (ui_perf_now_us() - perf_start_us));
#endif
}

void player_transition_cache_async_cb(void * unused) {
    (void) unused;
    /* Re-checked here, not just at the mark_dirty() call site: several
     * dirty notifications can each schedule their own async callback
     * before the first one runs (lv_async_call() doesn't dedupe by
     * callback/data), so every call after the first one that actually
     * rebuilds is a cheap no-op instead of a redundant re-snapshot. */
    if (player_transition_cache_dirty) player_transition_rebuild_cache();
}

/* Called from every site where something visible on gui_player_get_screen()'s own
 * subtree changes -- see this function's own doc comment on the cache
 * above for the current full list of call sites. Deliberately NOT called
 * from the routine per-second progress-bar update. */
void player_transition_mark_dirty(void) {
    player_transition_cache_dirty = true;
    if (gui_player_get_screen()) lv_async_call(player_transition_cache_async_cb, NULL);
}

/* Back-target transition-frame cache -- one slot, for whatever screen sits
 * directly below the current top of the nav stack (nav_push()'s own "from"
 * screen). That's exactly the destination a back-swipe or the hardware/
 * software back action targets, and real UI_PERF_TRACE data showed this is
 * the single biggest remaining begin_slide_transition_ex() cost once the
 * static/player caches don't apply: a synchronous lv_snapshot_take() of a
 * live, potentially large widget tree (a Files/Albums/Songs list, Settings,
 * etc), costing 13-27ms. Rebuilt asynchronously right when nav_push()
 * leaves a screen behind, not on every visit -- a few-seconds-stale
 * destination frame for a screen the user isn't even looking at is the same
 * accepted tradeoff player_transition_cache_buf above already makes.
 * Screen-only base -- persistent bars blended in fresh at transition time,
 * same as every other cache here. Deliberately skipped for static-snapshot
 * screens and the player screen (get_static_snapshot()/the player-cache
 * check both run first in begin_slide_transition_ex(), and back_target_
 * cache_rebuild_cb() below also declines to snapshot either kind) -- this
 * slot exists purely to cover the dynamic screens neither of those already
 * handle. Only hooked into nav_push() (the common case: tapping from Home/
 * a list into a deeper screen) -- not nav_push_stack_only()'s player-swipe-
 * commit call site, since that path already gets the compositor's fast
 * horizontal two-panel mode (reveal=false leaving Player) and the
 * remaining cold-snapshot tail there is a smaller, separate win not worth
 * the added complexity of exposing that path's own from_scr here too. */
static lv_obj_t * back_target_cache_screen = NULL;
static lv_draw_buf_t * back_target_cache_buf = NULL;

static void back_target_cache_rebuild_cb(void * unused) {
    (void) unused;
    if (!back_target_cache_screen) return;
    /* The screen we meant to cache may no longer be the thing a back-swipe
     * would target by the time this async callback actually runs (another
     * push could have landed first) -- covered by nav_push() re-pointing
     * this slot at the new "from" screen and destroying any stale buffer
     * before scheduling a fresh rebuild, so a stale screen pointer here
     * would already have been cleared. Also decline a screen that's live
     * right now (nothing to gain snapshotting what's on screen) or one
     * already covered by a faster dedicated cache. */
    if (lv_screen_active() == back_target_cache_screen) return;
    if (get_static_snapshot(back_target_cache_screen)) return;
    if (back_target_cache_screen == gui_player_get_screen()) return;
    lv_draw_buf_t * fresh = snapshot_screen_base(back_target_cache_screen);
    if (!fresh) return; /* OOM -- keep whatever's cached (stale beats nothing) */
    if (back_target_cache_buf) lv_draw_buf_destroy(back_target_cache_buf);
    back_target_cache_buf = fresh;
}

/* Destroys any cached buffer and, if the target screen is still valid,
 * schedules a fresh rebuild against it -- same shape as player_transition_
 * discard_cache() above. Callers that need the screen pointer itself
 * cleared (the screen is about to be freed) must do so BEFORE calling this,
 * so there's nothing left to reschedule a rebuild against. */
static void back_target_cache_discard(void) {
    if (back_target_cache_buf) lv_draw_buf_destroy(back_target_cache_buf);
    back_target_cache_buf = NULL;
    if (back_target_cache_screen) lv_async_call(back_target_cache_rebuild_cb, NULL);
}

void gui_navigation_invalidate_back_snapshot(lv_obj_t * screen) {
    if (screen && back_target_cache_screen == screen) back_target_cache_discard();
}

/* Called from nav_push() right after it decides `scr` is being left behind
 * (covered) by a new push -- `scr` is now exactly what a future back-swipe/
 * back-action from the new top of the stack would target. */
static void back_target_cache_note_covered(lv_obj_t * scr) {
    /* Skip static/player screens entirely -- get_static_snapshot()/player
     * checks in back_target_cache_rebuild_cb() above already decline to
     * snapshot them, so caching the pointer here would only ever sit idle
     * while still needing the exact same replace-time fixup real dynamic
     * screens do (see back_target_cache_note_replaced()'s own comment) --
     * narrower is safer than correct-but-pointless. */
    if (get_static_snapshot(scr) || scr == gui_player_get_screen()) scr = NULL;
    if (back_target_cache_screen != scr) back_target_cache_screen = scr;
    back_target_cache_discard();
}

/* Real use-after-free caught in review: nav_push() sets this cache's screen
 * pointer even for static/player screens the rebuild callback itself
 * declines to snapshot (get_static_snapshot()/gui_player_get_screen()
 * checks inside back_target_cache_rebuild_cb() above) -- e.g. leaving Home
 * still sets back_target_cache_screen to the OLD Home object. A theme/font
 * refresh then rebuilds Home as a brand-new lv_obj_t and deletes the old
 * one, but gui_navigation_replace_home()/gui_navigation_replace_static_
 * screen() (below) only ever fixed up nav_stack[] and the static-snapshot
 * array -- not this cache -- so the already-queued async rebuild callback
 * (scheduled by gui_navigation_invalidate_theme_snapshots()'s own call to
 * back_target_cache_discard() just above it) would run AFTER the old
 * screen is freed, calling snapshot_screen_base() on a dangling pointer.
 * Called from both replace functions below to keep this cache's pointer in
 * lockstep with theirs. */
static void back_target_cache_note_replaced(lv_obj_t * old_screen, lv_obj_t * new_screen) {
    if (back_target_cache_screen != old_screen) return;
    back_target_cache_screen = new_screen;
    back_target_cache_discard();
}

/* slide_transition_ctx_t defined in gui.h */

static bool slide_transition_active = false;

/* The home pill is a persistent top-layer object, but Lyrics deliberately
 * disables its gesture. Apply its visibility at real screen handoffs so it
 * is never restored early and baked into the outgoing Lyrics frame. */
static void sync_home_indicator_visibility(lv_obj_t * screen) {
    gui_shell_set_home_indicator_visible(current_settings.setup_complete &&
                                         current_settings.swipe_up_home_enabled &&
                                         screen != gui_shell_get_home_screen() &&
                                         screen != gui_lyrics_get_screen() &&
                                         screen != gui_lock_screen_get_screen());
}

/* Interactive swipe state (player_swipe_* and back_swipe_*) lives in
 * gui_shell.c. gui_shell_player_swipe_recover() resets both on compositor
 * failures so a freed slide_transition_ctx_t cannot be driven from a
 * still-set tracking pointer. */

/* Defers a full invalidation until the next lv_timer_handler() pass,
 * avoiding a re-entrant lv_refr_now() from within an animation or timer
 * callback. Used by compositor failure recovery and screen-wake handling. */
void full_redraw_async_cb(void * unused) {
    (void) unused;
    lv_obj_invalidate(lv_screen_active());
    lv_obj_invalidate(lv_layer_top());
    lv_obj_invalidate(lv_layer_sys());
}

void slide_transition_anim_x_cb(void * var, int32_t v) {
    slide_transition_ctx_t * ctx = (slide_transition_ctx_t *) var;
    /* TRANSITION_PERFORMANCE_PLAN.md Phase 3 -- when begin_slide_transition()
     * below handed this transition off to the direct-framebuffer compositor,
     * img_from/img_to are never drawn at all (LVGL invalidation is disabled
     * for the whole session), so driving them with lv_obj_set_x() here would
     * be pure wasted work: skip straight to compositing this frame instead.
     * Every caller of this function (screen_transition_slide_ex()'s own
     * lv_anim_t, poll_quick_drawer_drag()'s per-tick interactive drag, and
     * its release settle animation) goes through this one shared path, so
     * all three get compositor support with no changes of their own. */
    if (transition_compositor_is_active()) {
        if (!transition_compositor_frame(v)) {
            /* Hard presentation failure. transition_compositor_frame()
             * already restored normal fbdev/LVGL ownership. Recover to a
             * deterministic logical screen: a fixed transition or a
             * released/committed gesture keeps its destination (the nav
             * stack has already been updated); an in-progress or cancelled
             * gesture returns to the source (and has made no stack change).
             * The deferred invalidation avoids a re-entrant lv_refr_now()
             * from inside an animation/timer callback. */
            lv_anim_delete(ctx, slide_transition_anim_x_cb); /* safe no-op if ctx isn't driven by a real lv_anim_t (the raw per-tick interactive-drag path isn't) */
            lv_obj_t * recovery_scr = ctx->commit ? ctx->to_scr : ctx->from_scr;
            lv_screen_load(recovery_scr);
            sync_player_topbar_visibility(recovery_scr);
            sync_home_indicator_visibility(recovery_scr);
            lv_async_call(full_redraw_async_cb, NULL);
            if (ctx->overlay) lv_obj_delete(ctx->overlay);
            if (ctx->buf_from_owned) lv_draw_buf_destroy(ctx->buf_from);
            if (ctx->buf_to_owned) lv_draw_buf_destroy(ctx->buf_to);
            /* Resets gui_shell.c's REAL interactive-swipe state, not a
             * same-named local copy -- see gui_shell_player_swipe_recover()'s
             * own comment (gui_shell.h) for the real use-after-free this
             * fixes. Must run before the free below, while ctx is still a
             * valid pointer to compare against. */
            gui_shell_player_swipe_recover(ctx);
            gui_lock_screen_swipe_recover(ctx);
            lv_free(ctx);
            slide_transition_active = false;
        }
        return;
    }
    if (ctx->vertical) {
        lv_obj_set_y(ctx->img_from, v);
        if (!ctx->reveal) lv_obj_set_y(ctx->img_to, v + ctx->to_offset);
    } else {
        lv_obj_set_x(ctx->img_from, v);
        if (!ctx->reveal) lv_obj_set_x(ctx->img_to, v + ctx->to_offset);
    }
}

void slide_transition_done_cb(lv_anim_t * a) {
    slide_transition_ctx_t * ctx = (slide_transition_ctx_t *) lv_anim_get_user_data(a);
    lv_obj_t * final_scr = ctx->commit ? ctx->to_scr : ctx->from_scr;
    if (ctx->commit) {
        lv_screen_load(ctx->to_scr);
    }
    /* The fallback owns flattened full-screen images, including both
     * persistent bands, so their live layer objects stay hidden throughout
     * the slide. Restore the status bar for the screen actually selected
     * and restore the screen-independent home-indicator setting now. */
    sync_player_topbar_visibility(final_scr);
    lv_obj_t * hb_sup = gui_shell_get_home_indicator_band();
    if (ctx->fallback_bands_suppressed && hb_sup) {
        if (ctx->home_indicator_was_hidden)
            lv_obj_add_flag(hb_sup, LV_OBJ_FLAG_HIDDEN);
        else
            lv_obj_remove_flag(hb_sup, LV_OBJ_FLAG_HIDDEN);
    }
    sync_home_indicator_visibility(final_scr);
    if (ctx->overlay) lv_obj_delete(ctx->overlay); /* deletes img_from/img_to too -- NULL when this transition was handed to the compositor instead (see begin_slide_transition()'s own comment on why the overlay is skipped entirely there, not just left undrawn) */
    if (ctx->buf_from_owned) lv_draw_buf_destroy(ctx->buf_from);
    if (ctx->buf_to_owned) lv_draw_buf_destroy(ctx->buf_to);
    transition_compositor_end(); /* no-op if the compositor was never activated for this transition */
    lv_free(ctx);
    slide_transition_active = false;
}

void slide_transition_cancel(slide_transition_ctx_t ** pctx) {
    if (!pctx || !*pctx) {
        if (transition_compositor_is_active()) {
            transition_compositor_end();
        }
        slide_transition_active = false;
        return;
    }
    slide_transition_ctx_t * ctx = *pctx;
    *pctx = NULL;

    /* Delete any pending or in-flight animation for this context to prevent use-after-free */
    lv_anim_delete(ctx, slide_transition_anim_x_cb);

    /* Restore the source screen and topbar */
    lv_obj_t * recovery_scr = ctx->from_scr;
    if (recovery_scr) {
        lv_screen_load(recovery_scr);
        sync_player_topbar_visibility(recovery_scr);
        sync_home_indicator_visibility(recovery_scr);
    }

    /* Restore home indicator band visibility */
    lv_obj_t * hb_sup = gui_shell_get_home_indicator_band();
    if (ctx->fallback_bands_suppressed && hb_sup) {
        if (ctx->home_indicator_was_hidden)
            lv_obj_add_flag(hb_sup, LV_OBJ_FLAG_HIDDEN);
        else
            lv_obj_remove_flag(hb_sup, LV_OBJ_FLAG_HIDDEN);
    }

    /* Delete overlay and destroy buffers */
    if (ctx->overlay) {
        lv_obj_delete(ctx->overlay);
        ctx->overlay = NULL;
    }
    if (ctx->buf_from_owned && ctx->buf_from) {
        lv_draw_buf_destroy(ctx->buf_from);
        ctx->buf_from = NULL;
        ctx->buf_from_owned = false;
    }
    if (ctx->buf_to_owned && ctx->buf_to) {
        lv_draw_buf_destroy(ctx->buf_to);
        ctx->buf_to = NULL;
        ctx->buf_to_owned = false;
    }

    transition_compositor_end();
    lv_free(ctx);
    slide_transition_active = false;
}


/* Shared setup for both screen_transition_slide_ex()'s own fixed-duration
 * path and the interactive (finger-driven) player-swipe further down
 * (poll_quick_drawer_drag()'s player_swipe_* state) -- snapshotting
 * from_scr/to_scr and building the two-image overlay is identical either
 * way; only how the resulting ctx gets ANIMATED afterward differs (one
 * fixed lv_anim_t vs. driven directly from live touch position, then a
 * short commit/cancel settle animation). Returns NULL if to_scr is
 * already active, a transition is already in flight, or a snapshot
 * failed (OOM) -- the caller should fall back to an instant
 * lv_screen_load(to_scr) in every one of those cases (screen_transition_slide_ex()
 * does; the interactive path just abandons the gesture and lets it fall
 * through as whatever else it might have been, since there's no
 * "genuinely already there" case to fall back to for a still-in-progress
 * drag). ctx->commit defaults to true, matching every existing caller
 * (only the interactive path ever sets it false, on a cancelled drag).
 *
 * Both transition sources are always OWNED, independent copies now
 * Both transition sources are always owned, independent copies
 * (never live aliases of framebuffer memory, nor direct references to a cache
 * buffer): (1) a live-aliased outgoing frame could bleed through live
 * redraws happening on from_scr during a drag; (2) when direct-framebuffer
 * compositing is active, the physical pages ping-pong every frame, which
 * would create an overlapping read/write hazard with an aliased source. */
slide_transition_ctx_t * begin_slide_transition(lv_obj_t * to_scr, bool forward) {
    return begin_slide_transition_ex(to_scr, forward, false, false);
}

slide_transition_ctx_t * begin_slide_transition_ex(lv_obj_t * to_scr, bool forward, bool vertical, bool reveal) {
#ifdef UI_PERF_TRACE
    uint64_t perf_begin_us = ui_perf_now_us();
    uint64_t perf_drain_done_us;
    uint64_t perf_to_done_us;
    uint64_t perf_from_done_us;
#endif
    lv_obj_t * from_scr = lv_screen_active();
    if (from_scr == to_scr || slide_transition_active) return NULL;

    lv_display_t * disp = lv_display_get_default();
    int32_t w = lv_display_get_horizontal_resolution(disp);
    int32_t h = lv_display_get_vertical_resolution(disp);

    /* Real bug caught in review: disabling invalidation below only stops
     * NEW invalidations -- it does nothing about an area some OTHER timer
     * already queued dirty before this tick's own gesture/nav timer ran
     * (LVGL's timer list is LIFO -- lv_timer_create() inserts at the head
     * and lv_timer_handler() walks head-first, so a more-recently-created
     * timer like this module's own gesture polling can run BEFORE the
     * display's own refresh timer in the very same tick, not after, the
     * opposite of what an earlier version of this comment assumed).
     * DIRECT-mode rendering (this driver's LV_LINUX_FBDEV_RENDER_MODE)
     * draws straight into a physical framebuffer page, so if that stale
     * queued area is left to render once invalidation is re-enabled or the
     * compositor takes over, it can stomp physical pixels the compositor
     * is actively managing -- the fbdev driver's external-composition guard
     * only suppresses the subsequent PAN, not the render that already
     * happened. A synchronous drain here, before this function's OWN
     * snapshot-prep work below has dirtied anything itself, flushes
     * whatever a truly external timer left queued -- unlike the drain this
     * replaced (removed for being 12-20ms on real hardware), this one runs
     * before any self-inflicted dirtying exists, so the common case (no
     * unrelated timer mid-flight) is cheap; only a genuinely-external
     * pending redraw costs anything here. */
    lv_refr_now(disp);
#ifdef UI_PERF_TRACE
    perf_drain_done_us = ui_perf_now_us();
#endif

    slide_transition_ctx_t * ctx = lv_malloc(sizeof(*ctx));
    if (!ctx) return NULL;
    /* Nothing this function's own snapshot-prep code does (hiding the
     * dismiss button, toggling the status bar / home indicator bands,
     * restyling via gui_shell_set_status_bar_screen_context()) should be
     * allowed to reach the physical screen while we're about to capture it
     * as a frozen 'from' snapshot -- lv_display_enable_invalidation(false)
     * makes those self-inflicted invalidations a silent no-op. Deliberately
     * narrow: re-enabled immediately below, right after buf_from is
     * captured, NOT held disabled for the rest of the transition -- the
     * LVGL-overlay fallback further down (when the compositor declines)
     * creates real lv_obj_t/
     * lv_image_t children and drives them via lv_obj_set_x/set_y for the
     * whole gesture, which only ever reaches the screen through LVGL's
     * normal invalidate-then-redraw pipeline -- leaving invalidation
     * disabled through that branch would make every one of those calls a
     * silent no-op (_lv_inv_area()/lv_obj_invalidate_area() both bail
     * immediately when disabled), so the fallback would never actually
     * draw a moving frame at all. transition_compositor_begin() below
     * re-disables invalidation itself, on its own separate, already-correct
     * disable/enable pairing, for the entirely different reason of keeping
     * LVGL's normal pipeline off the physical framebuffer while it writes
     * to it directly -- that pairing is untouched by this one.
     * Capturing the currently-active scanned-out page is already correct
     * and up to date without any of that: the lv_refr_now() call above,
     * before any of this function's own work, already flushed whatever a
     * genuinely external timer left queued dirty -- do NOT assume LVGL's
     * own display-refresh timer happens to run before this one in a given
     * tick just because it was created first; lv_timer_create() inserts at
     * the list head and lv_timer_handler() walks head-first, so a more-
     * recently-created timer (this module's own gesture polling included)
     * can run BEFORE it in the very same tick, not after. */
    lv_display_enable_invalidation(disp, false);
    ctx->commit = true;
    ctx->buf_from_owned = true;
    ctx->buf_to_owned = true;
    ctx->fallback_bands_suppressed = false;
    ctx->home_indicator_was_hidden = true;

    /* Incoming source prepared first, before capturing the outgoing physical
     * page. Produces a complete flattened frame (screen content plus persistent
     * bars). Cached bases (static screens or player cache) are duplicated rather
     * than referenced directly to prevent use-after-free if the cache is
     * rebuilt asynchronously, while persistent bars are blended fresh. */
    lv_draw_buf_t * buf_to;
#ifdef UI_PERF_TRACE
    bool used_player_cache = false;
#endif
    lv_draw_buf_t * cached_base = get_static_snapshot(to_scr);
    if (!cached_base && to_scr == gui_player_get_screen() && player_transition_cache_buf) {
        cached_base = player_transition_cache_buf;
#ifdef UI_PERF_TRACE
        used_player_cache = true;
#endif
    }
    if (!cached_base && to_scr == back_target_cache_screen && back_target_cache_buf) {
        cached_base = back_target_cache_buf;
    }
    if (cached_base) {
        buf_to = lv_draw_buf_dup(cached_base);
        if (buf_to) blend_persistent_bars(buf_to, to_scr);
    } else {
        buf_to = build_flattened_transition_frame(to_scr);
    }
#ifdef UI_PERF_TRACE
    perf_to_done_us = ui_perf_now_us();
#endif

    /* Outgoing source: an owned copy of the physical scanout page.
     * Invalidation was disabled above, so snapshot-prep cannot pan us onto
     * a different page. lv_linux_fbdev_get_active_page() is the
     * fbdev driver's accessor for the physical half currently being scanned
     * out; lv_display_get_buf_active() is used as fallback (host/SDL builds,
     * or if fbdev pan-based double buffering is inactive). */
    lv_draw_buf_t * buf_from = NULL;
#if LV_USE_LINUX_FBDEV
    if (lv_display_get_rotation(disp) == LV_DISPLAY_ROTATION_0) {
        const void * phys_active = lv_linux_fbdev_get_active_page(disp);
        uint32_t fb_stride = lv_linux_fbdev_get_stride(disp);
        if (phys_active && fb_stride != 0) {
            lv_draw_buf_t phys_desc;
            memset(&phys_desc, 0, sizeof(phys_desc));
            phys_desc.header.magic = LV_IMAGE_HEADER_MAGIC;
            phys_desc.header.cf = LV_COLOR_FORMAT_RGB565;
            phys_desc.header.w = (uint32_t) w;
            phys_desc.header.h = (uint32_t) h;
            phys_desc.header.stride = fb_stride;
            phys_desc.data = (uint8_t *) phys_active; /* lv_draw_buf_dup() below only reads this -- never written through phys_desc itself */
            phys_desc.data_size = fb_stride * (uint32_t) h;
            buf_from = lv_draw_buf_dup(&phys_desc);
        }
    }
#endif
    if (!buf_from) {
        lv_draw_buf_t * active_buf = lv_display_get_buf_active(disp);
        buf_from = active_buf ? lv_draw_buf_dup(active_buf) : lv_snapshot_take(from_scr, LV_COLOR_FORMAT_RGB565);
    }
#ifdef UI_PERF_TRACE
    perf_from_done_us = ui_perf_now_us();
#endif
    /* Re-enable now that both snapshots are safely captured -- see the
     * disable's own comment above for why this window is deliberately
     * narrow rather than held for the whole transition. */
    lv_display_enable_invalidation(disp, true);
    if (!buf_from || !buf_to) {
        /* Snapshot failed (e.g. OOM) -- caller falls back to an instant cut
         * rather than crash or get stuck mid-navigation/mid-drag. */
        if (buf_from && ctx->buf_from_owned) lv_draw_buf_destroy(buf_from);
        if (buf_to && ctx->buf_to_owned) lv_draw_buf_destroy(buf_to);
        lv_free(ctx);
        return NULL;
    }

    int32_t to_offset = vertical ? (forward ? h : -h) : (forward ? w : -w);
    ctx->buf_from = buf_from;
    ctx->buf_to = buf_to;
    ctx->from_scr = from_scr;
    ctx->to_scr = to_scr;
    ctx->to_offset = to_offset;
    ctx->vertical = vertical;
    ctx->reveal = reveal;

    slide_transition_active = true;

    /* Handoff transition to the direct-framebuffer compositor before
     * creating LVGL overlay/image objects. Skipping overlay objects when
     * the compositor takes over avoids queuing initial-draw invalidations
     * that could flash during compositing. The compositor's fast path
     * handles either axis, including reveal (destination pinned at (0,0),
     * source slides over/off it). This keeps vertical Home gestures from
     * redrawing the live custom player underneath moving image overlays. */
    if (transition_compositor_begin_ex(buf_from, buf_to, to_offset, vertical, reveal)) {
        ctx->overlay = NULL;
        ctx->img_from = NULL;
        ctx->img_to = NULL;
    } else {
        /* buf_from/buf_to already contain the persistent bands. Hide the
         * live layer copies for the whole fallback animation so they move
         * exactly once as part of those flattened frames instead of being
         * drawn a second time, stationary, above the sliding images. */
        ctx->fallback_bands_suppressed = true;
        lv_obj_t * hb_sl = gui_shell_get_home_indicator_band();
        lv_obj_t * sb_sl = gui_shell_get_status_bar_band();
        if (hb_sl) {
            ctx->home_indicator_was_hidden =
                lv_obj_has_flag(hb_sl, LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(hb_sl, LV_OBJ_FLAG_HIDDEN);
        }
        if (sb_sl)
            lv_obj_add_flag(sb_sl, LV_OBJ_FLAG_HIDDEN);

        lv_obj_t * overlay = lv_obj_create(lv_layer_top());
        lv_obj_remove_style_all(overlay);
        lv_obj_set_size(overlay, lv_pct(100), lv_pct(100));
        lv_obj_set_pos(overlay, 0, 0);
        lv_obj_clear_flag(overlay, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_flag(overlay, LV_OBJ_FLAG_CLICKABLE); /* swallow touches while the slide is in flight */
        /* Keep transient top-layer UI such as the volume popup above the
         * transition. The persistent bands themselves are hidden above. */
        lv_obj_move_to_index(overlay, 0);

        lv_obj_t * img_from = lv_image_create(overlay);
        lv_image_set_src(img_from, buf_from);
        lv_obj_set_pos(img_from, 0, 0);

        lv_obj_t * img_to = lv_image_create(overlay);
        lv_image_set_src(img_to, buf_to);
        /* reveal: destination starts (and stays, see slide_transition_anim_
         * x_cb()) at (0,0) -- already "in place," uncovered as img_from
         * slides away over it, rather than sliding in from the offset. */
        lv_obj_set_pos(img_to, reveal ? 0 : (vertical ? 0 : to_offset),
                              reveal ? 0 : (vertical ? to_offset : 0));
        /* img_to is added after img_from, so LVGL draws it on top by
         * default -- irrelevant for the two-panel slide (the two images
         * never overlap, always exactly adjacent), but reveal keeps img_to
         * stationary directly underneath img_from for the whole gesture, so
         * img_from must stay the top child or Home would show through
         * immediately instead of being uncovered as it slides away. */
        if (reveal) lv_obj_move_foreground(img_from);

        ctx->overlay = overlay;
        ctx->img_from = img_from;
        ctx->img_to = img_to;
    }
#ifdef UI_PERF_TRACE
    uint64_t perf_end_us = ui_perf_now_us();
    printf("PERF transition begin_us=%llu drain_us=%llu to_us=%llu from_us=%llu setup_us=%llu from_owned=%d to_owned=%d player_cache=%d cache_dirty=%d compositor=%d\n",
           (unsigned long long) (perf_end_us - perf_begin_us),
           (unsigned long long) (perf_drain_done_us - perf_begin_us),
           (unsigned long long) (perf_to_done_us - perf_drain_done_us),
           (unsigned long long) (perf_from_done_us - perf_to_done_us),
           (unsigned long long) (perf_end_us - perf_from_done_us),
           ctx->buf_from_owned, ctx->buf_to_owned,
           used_player_cache, player_transition_cache_dirty, transition_compositor_is_active());
#endif
    return ctx;
}

static void screen_transition_slide_ex(lv_obj_t * to_scr, bool forward, bool vertical, bool reveal) {
    /* Animation Speed Off: cut straight to the screen, no snapshots. */
    slide_transition_ctx_t * ctx = gui_anims_off() ? NULL : begin_slide_transition_ex(to_scr, forward, vertical, reveal);
    if (!ctx) {
        lv_screen_load(to_scr);
        sync_player_topbar_visibility(to_scr);
        sync_home_indicator_visibility(to_scr);
        return;
    }

    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_var(&a, ctx);
    lv_anim_set_user_data(&a, ctx);
    lv_anim_set_values(&a, 0, -ctx->to_offset);
    lv_anim_set_duration(&a, gui_anim_ms(NAV_ANIM_TIME_MS));
    lv_anim_set_exec_cb(&a, slide_transition_anim_x_cb);
    lv_anim_set_completed_cb(&a, slide_transition_done_cb);
    lv_anim_set_path_cb(&a, lv_anim_path_ease_out);
    lv_anim_start(&a);
}

void nav_push(lv_obj_t * scr) {
#ifdef UI_PERF_TRACE
    uint64_t perf_start_us = ui_perf_now_us();
#endif
    if (nav_depth > 0 && nav_stack[nav_depth - 1] == scr) {
        lv_screen_load(scr); /* already the active screen -- nothing to push */
        sync_player_topbar_visibility(scr);
        sync_home_indicator_visibility(scr);
        return;
    }
    if (nav_depth > 0) back_target_cache_note_covered(nav_stack[nav_depth - 1]);
    if (nav_depth < NAV_STACK_MAX) {
        nav_stack[nav_depth++] = scr;
    }
    /* Forward navigation cuts instantly; back navigation (nav_pop) slides. */
    lv_screen_load(scr);
    sync_player_topbar_visibility(scr);
    sync_home_indicator_visibility(scr);
#ifdef UI_PERF_TRACE
    printf("PERF nav_push load_us=%llu depth=%d\n",
           (unsigned long long) (ui_perf_now_us() - perf_start_us), nav_depth);
#endif
}

void nav_push_stack_only(lv_obj_t * scr) {
    if (nav_depth > 0 && nav_stack[nav_depth - 1] == scr) return;
    if (nav_depth < NAV_STACK_MAX) nav_stack[nav_depth++] = scr;
}

/* A covered text view is already unloaded, so dropping its stack entry
 * never delivers another LV_EVENT_SCREEN_UNLOADED. on_close stays queued
 * until a slide already in progress has finished. */
static void note_text_view_if_dropped(void) {
    gui_text_view_note_nav_removed();
}

void nav_pop_ex(bool forward, bool vertical, bool reveal) {
    if (!current_settings.setup_complete && lv_screen_active() == gui_setup_get_screen()) return;
    if (nav_depth > 1) {
        lv_obj_t * removed = nav_stack[nav_depth - 1];
        nav_depth--;
        cancel_text_input_if_unstacked(removed);
    }
    /* Keep the outgoing screen's bars untouched until its physical frame
     * has been captured. The transition completion/cut-fallback path
     * applies the destination state at the actual screen handoff. */
    screen_transition_slide_ex(nav_stack[nav_depth - 1], forward, vertical, reveal);
    note_text_view_if_dropped();
}

void nav_pop(void) {
    nav_pop_ex(false, false, false);
}

void nav_pop_stack_only(void) {
    if (nav_depth > 1) {
        lv_obj_t * removed = nav_stack[nav_depth - 1];
        nav_depth--;
        cancel_text_input_if_unstacked(removed);
    }
    note_text_view_if_dropped();
}

/* Splices the stack slot at `index` out entirely (shifting everything
 * above it down by one), with no screen load of any kind -- used when a
 * transient interstitial screen (Wi-Fi/Subsonic's "Connecting..."/
 * "Downloading..." screen, or a chained show_text_entry() call) has
 * already been left behind by something that pushed a different screen on
 * top of it instead of returning to it.
 * Bookkeeping only -- whatever is currently on screen was already loaded
 * by the nav_push() that grew the stack past `index`. */
void nav_remove_stack_slot(int index) {
    if (index < 0 || index >= nav_depth) return;
    lv_obj_t * removed = nav_stack[index];
    for (int i = index; i < nav_depth - 1; i++) nav_stack[i] = nav_stack[i + 1];
    if (nav_depth > 0) nav_depth--;
    cancel_text_input_if_unstacked(removed);
    note_text_view_if_dropped();
}

/* Collapses the whole nav stack back to Home -- used after a library rescan,
 * since any deeper screen (Artists/Albums/group songs/...) may be showing
 * rows built from the pre-rescan data and would otherwise still be reachable
 * via back-navigation. */
/* Where "home" actually is right now.
 *
 * In USB DAC mode the device presents itself to a PC as a sound card and the
 * DAC overlay owns the whole screen (see gui_network.c's mode-switch success
 * path) -- it cannot sensibly be used as a normal music player at the same
 * time, so the ordinary Home is not a destination the user is meant to reach
 * while that holds. Routing every reset-to-home through here keeps that true
 * for all of them, rather than only the one path that happened to be
 * reported. Falls back to Home if the overlay was never built. */
static lv_obj_t * nav_home_target(void) {
    if (gui_network_usb_dac_mode_active()) {
        lv_obj_t * dac_overlay = gui_network_get_usb_dac_overlay();
        if (dac_overlay) return dac_overlay;
    }
    return gui_shell_get_home_screen();
}

void nav_reset_to_home(void) {
    if (!current_settings.setup_complete) return;
    lv_obj_t * target = nav_home_target();
    bool removed_text_entry = false;
    lv_obj_t * text_entry = gui_text_input_get_screen();
    for (int i = 0; i < nav_depth; i++) {
        if (nav_stack[i] == text_entry) removed_text_entry = true;
    }
    nav_depth = 1;
    nav_stack[0] = target;
    /* Check after replacing the stack so a retained target can keep a prompt. */
    if (removed_text_entry) cancel_text_input_if_unstacked(text_entry);
    lv_screen_load(target);
    sync_player_topbar_visibility(target);
    sync_home_indicator_visibility(target);
    note_text_view_if_dropped();
}

void nav_reset_to_home_stack_only(void) {
    if (!current_settings.setup_complete) return;
    bool removed_text_entry = false;
    lv_obj_t * text_entry = gui_text_input_get_screen();
    for (int i = 0; i < nav_depth; i++) {
        if (nav_stack[i] == text_entry) removed_text_entry = true;
    }
    nav_depth = 1;
    nav_stack[0] = nav_home_target();
    if (removed_text_entry) cancel_text_input_if_unstacked(text_entry);
    note_text_view_if_dropped();
}

/* Shared back-button handler for every screen built via the reusable
 * icon-grid/pill-list builders -- passed directly as their back_btn_cb. */
void generic_back_cb(lv_event_t * e) {
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    nav_pop();
}

/* Sets LV_OBJ_FLAG_GESTURE_BUBBLE on every descendant of `obj` so a swipe
 * started anywhere inside a screen (over a label, button, or scrollable
 * list) bubbles up to the screen itself to be handled as app-wide
 * navigation. Deliberately does NOT recurse into drag-to-adjust widgets
 * (sliders/switches/dropdowns/rollers) -- those consume horizontal drags
 * themselves (e.g. seeking the progress bar), and letting a big drag on one
 * of those also fire a navigation swipe would be surprising. */
void enable_gesture_bubble_recursive(lv_obj_t * obj) {
    uint32_t count = lv_obj_get_child_count(obj);
    for (uint32_t i = 0; i < count; i++) {
        lv_obj_t * child = lv_obj_get_child(obj, i);
        if (lv_obj_check_type(child, &lv_slider_class) ||
            lv_obj_check_type(child, &lv_switch_class) ||
            lv_obj_check_type(child, &lv_dropdown_class) ||
            lv_obj_check_type(child, &lv_roller_class)) {
            continue;
        }
        lv_obj_add_flag(child, LV_OBJ_FLAG_GESTURE_BUBBLE);
        enable_gesture_bubble_recursive(child);
    }
}

/* Used by screen_gesture_event_cb() below -- defined later with the drawer
 * and dead-zone machinery. */
#define QUICK_DRAWER_ANIM_MS 120 /* post-release snap animation duration */
#define QUICK_DRAWER_TRIGGER_ZONE BOARD_SCALE_PX(140) /* swipe-down must start within this many px of the top edge to open it */

/* Global swipe handling for back/forward nav. Swipe left-to-right (finger
 * drags rightward) = go back. Swipe right-to-left = jump to the player
 * screen. Registered per-screen in finalize_screen_navigation().
 *
 * Quick-access drawer drag is handled via poll_quick_drawer_drag() rather
 * than gesture events due to high density of interactive widgets on the
 * drawer surface. */

/* Forward-declared from the search-binding section below: closes an active
 * inline search before the back-swipe navigates away. */

/* Forward-declared from gui_library.c: steps up one directory in Files
 * instead of leaving the screen. */

static void screen_gesture_event_cb(lv_event_t * e) {
    if (lv_event_get_code(e) != LV_EVENT_GESTURE) return;
    lv_indev_t * indev = lv_indev_active();
    if (!indev) return;

    /* Check whether press is over a drag-adjust widget or within a swipe dead
     * zone (e.g. player progress slider) to prevent accidental back-swipe
     * triggers while seeking. */
    lv_point_t gesture_press_point;
    lv_indev_get_point(indev, &gesture_press_point);
    if (active_press_is_over_drag_adjust_widget() || point_in_swipe_dead_zone(gesture_press_point)) return;

    lv_dir_t dir = lv_indev_get_gesture_dir(indev);
    /* poll_quick_drawer_drag()'s back_swipe_* already owns this whole press
     * once it judges the press eligible at press-down -- see gui_shell.c's
     * own comment on gui_shell_back_swipe_owns_press() for why this check,
     * not just wait_release() at deadzone-confirm time, is what actually
     * prevents double-handling: LVGL's own gesture recognition can dispatch
     * LV_EVENT_GESTURE for this same press before that poll-based deadzone
     * has had a tick to confirm, on a fast enough swipe. */
    if (dir == LV_DIR_RIGHT && gui_shell_back_swipe_owns_press()) return;
    if (dir == LV_DIR_RIGHT) {
        lv_obj_t * active_screen = lv_screen_active();
        DB_LOG("GESTURE", "screen_gesture_event_cb RIGHT fired screen=%s",
               active_screen == gui_library_get_files_screen() ? "files" : "other");
        if (!search_close_if_active_for_screen(active_screen) &&
            !file_browser_back_if_not_root_for_screen(active_screen)) {
            nav_pop();
        }
        /* The finger is still down mid-gesture when the screen swaps out
         * from under it -- without this, its eventual release gets
         * delivered to whatever object now sits at that same coordinate on
         * the new screen, firing an unwanted click there. Telling the
         * indev to disregard everything until the next physical release
         * stops that bleed-through. */
        lv_indev_wait_release(indev);
    }
    /* Interactive swipe-left to player, swipe-right to back, and swipe-up
     * to Home are all handled in poll_quick_drawer_drag() before the
     * built-in gesture threshold -- see its own home_swipe_, back_swipe_,
     * and player_swipe_ state. The Home gesture only fires from drags
     * starting within the reserved bottom indicator band
     * (build_home_indicator_bar()). */
}

/* Finishing touch every build_XXX_screen() calls just before returning: wire
 * up the swipe gestures generically instead of repeating this per screen. */
void finalize_screen_navigation(lv_obj_t * scr) {
    /* lv_obj_hit_test() -- and therefore all press/drag/gesture detection --
     * bails out immediately for any object lacking LV_OBJ_FLAG_CLICKABLE
     * (confirmed by reading lv_obj_hit_test() in lv_obj_pos.c). A plain
     * lv_obj_create(NULL) screen doesn't have that flag by default, so a
     * swipe starting on bare screen background (anywhere not already
     * covered by a clickable child) would otherwise never even register as
     * a press, let alone a gesture. */
    lv_obj_add_flag(scr, LV_OBJ_FLAG_CLICKABLE);
    /* Every inner container built by this codebase already has SCROLLABLE
     * removed, but the screen root itself never did -- left scrollable (the
     * lv_obj default), a drag is first consumed as a scroll attempt (visible
     * on real hardware as the whole screen dragging/rubber-banding) and only
     * escalates to a real LV_EVENT_GESTURE in narrower cases, which is why
     * swipe-to-go-back wasn't firing reliably. None of these screens use
     * their own root as a scroll viewport -- scrolling, where it exists,
     * always happens on a dedicated inner list/container instead. */
    lv_obj_remove_flag(scr, LV_OBJ_FLAG_SCROLLABLE);
    enable_gesture_bubble_recursive(scr);
    /* LV_EVENT_PRESSED is deliberately NOT registered here -- see the
     * indev-level registration in gui_init() below for why. */
    lv_obj_add_event_cb(scr, screen_gesture_event_cb, LV_EVENT_GESTURE, NULL);
}



void gui_navigation_init(void) {
    register_static_snapshot(0, gui_shell_get_home_screen());
    register_static_snapshot(1, gui_library_get_music_screen());
    register_static_snapshot(2, stream_media_screen);
    register_static_snapshot(3, gui_network_get_wireless_screen());
    register_static_snapshot(4, gui_books_get_screen());
    register_static_snapshot(5, gui_settings_get_about_screen());
    register_static_snapshot(6, gui_settings_get_screen());
    register_static_snapshot(7, gui_settings_get_system_screen());
    register_static_snapshot(8, gui_shell_get_dac_home_screen());

    nav_stack[0] = gui_shell_get_home_screen();
    nav_depth = 1;
    lv_screen_load(gui_shell_get_home_screen());
    /* Every other transition (nav_push/nav_pop/nav_reset_to_home) syncs the
     * home indicator pill after loading a screen -- this boot-time load is
     * the one path that didn't, so the pill (visible by default in
     * build_home_indicator_bar() whenever swipe_up_home_enabled) stayed
     * shown on Home from cold boot until the first real navigation away and
     * back corrected it. */
    sync_home_indicator_visibility(gui_shell_get_home_screen());
}



/* For gui_reload.c's in-process UI reload -- run BEFORE any module deletes
 * its own screens, so nothing here is left pointing at an object that's
 * about to be freed. Only resets gui_navigation.c's own state (the nav
 * stack and its snapshot/transition-cache buffers); it does not, and must
 * not, lv_obj_delete() the screens themselves -- each screen is owned and
 * freed by its own module's teardown function (gui_shell_teardown(),
 * gui_network_teardown(), etc.), called separately by the reload
 * orchestrator. gui_navigation_init() (called again after every screen is
 * rebuilt) re-registers the snapshots and restores nav_stack/nav_depth to
 * Home on its own -- no separate "restore navigation" step is needed. */
void gui_navigation_teardown(void) {
    for (int i = 0; i < NAV_STACK_MAX; i++) nav_stack[i] = NULL;
    nav_depth = 0;
    for (int i = 0; i < STATIC_SNAPSHOT_SCREEN_COUNT; i++) {
        if (static_snapshot_buf[i]) lv_draw_buf_destroy(static_snapshot_buf[i]);
        static_snapshot_buf[i] = NULL;
        static_snapshot_screen[i] = NULL;
        static_snapshot_scroll_state[i] = 0;
    }
    player_transition_discard_cache();
    /* Unlike the font/theme-invalidate call sites above, the screen this
     * slot points at is about to be freed by the reload orchestrator --
     * clear back_target_cache_screen FIRST (not just the buffer), before
     * discarding, so a subsequent begin_slide_transition_ex() can never
     * match a stale, freed pointer (or worse, one reused by a newly-built
     * screen at the same address) against a would-be cache hit, and
     * back_target_cache_discard() below has no still-valid screen left to
     * schedule a pointless rebuild against. */
    back_target_cache_screen = NULL;
    back_target_cache_discard();
}

/* Returns true while a committed slide transition is still animating.
 * Interactive drag states are tracked in gui_shell.c and cancelled via
 * gui_shell_reset_drag_state().
 *
 * Used by gui_reload to defer reload requests until an in-flight slide
 * animation completes. */
bool gui_navigation_transition_in_progress(void) {
    return slide_transition_active;
}

int gui_navigation_get_depth(void) {
    return nav_depth;
}

lv_obj_t * gui_navigation_get_screen_at(int index) {
    if (index < 0 || index >= nav_depth) return NULL;
    return nav_stack[index];
}

bool gui_navigation_is_top(lv_obj_t * screen) {
    return (nav_depth > 0 && nav_stack[nav_depth - 1] == screen);
}

bool gui_navigation_contains(lv_obj_t * screen) {
    for (int i = 0; i < nav_depth; i++) {
        if (nav_stack[i] == screen) return true;
    }
    return false;
}

void gui_navigation_remove_screen_instances(lv_obj_t ** screens, int count) {
    for (int j = 0; j < count; j++) {
        for (int i = nav_depth - 1; i >= 0; i--) {
            if (nav_stack[i] == screens[j]) {
                nav_remove_stack_slot(i);
            }
        }
        /* These screens are being deleted outright (not replaced by a new
         * instance) -- clear rather than reschedule, same reasoning as
         * gui_navigation_teardown()'s own screen-pointer clear. */
        if (back_target_cache_screen == screens[j]) {
            back_target_cache_screen = NULL;
            back_target_cache_discard();
        }
    }
}

void gui_navigation_replace_home(lv_obj_t * old_screen, lv_obj_t * new_screen) {
    for (int i = 0; i < nav_depth; i++) {
        if (nav_stack[i] == old_screen) nav_stack[i] = new_screen;
    }
    register_static_snapshot(0, new_screen);
    back_target_cache_note_replaced(old_screen, new_screen);
    if (lv_screen_active() == old_screen) lv_screen_load(new_screen);
}

void gui_navigation_replace_static_screen(int snapshot_index, lv_obj_t * old_screen, lv_obj_t * new_screen) {
    for (int i = 0; i < nav_depth; i++) {
        if (nav_stack[i] == old_screen) nav_stack[i] = new_screen;
    }
    register_static_snapshot(snapshot_index, new_screen);
    back_target_cache_note_replaced(old_screen, new_screen);
    if (lv_screen_active() == old_screen) lv_screen_load(new_screen);
}
