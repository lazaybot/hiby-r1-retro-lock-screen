# HiBy R1 Retro Lock Screen

This directory contains the files and documentation for a retro handheld-style lock screen built on top of [Compas Player](https://github.com/Starnished66/compas-player).

The repository preserves the complete Compas Player source tree because the customization changes its C source and must remain reproducible under GPL-3.0. The original project and its contributors retain credit for the player, firmware tooling, and surrounding codebase. Our changes are limited to the lock-screen presentation and an additional 10-second display-timeout option.

## Features

- Pixel-style clock, date, battery indicator, and unlock prompt
- Retro handheld color palette and layout
- Four supplied 480 x 800 lock-screen backgrounds
- Automatic activation when the chosen image filename contains `GameBoy-Lock-Screen`
- Optional 10-second display timeout
- Normal Compas lock-screen behavior for all other image names

## Start here

1. Read [BUILD.md](BUILD.md) to build the player from source.
2. Review [BUILD_VERIFICATION.md](BUILD_VERIFICATION.md) for the latest compilation result and unresolved warning.
3. Read [INSTALL.md](INSTALL.md) before copying anything to a device.
4. Read [ITERATIONS.md](ITERATIONS.md) for the recorded r2-r8 development history and limitations.
5. Read [SAFETY.md](SAFETY.md) for the recovery and compatibility boundaries.

The project does not include stock HiBy firmware, personal device backups, music, library databases, or proprietary base images.

## Assets

Copy one image from `assets/` to the R1 microSD card and select it as the Compas image lock screen. Do not rename it unless the new filename still contains `GameBoy-Lock-Screen`; that substring is how the current code enables the specialized layout.

The phrase “Game Boy” is used descriptively for a fan-made visual style. Nintendo did not create, sponsor, or endorse this project. A future revision should replace the in-interface `GAME BOY` label with a generic name before wider distribution.

