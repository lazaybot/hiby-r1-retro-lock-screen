# Install on a HiBy R1

These instructions update only the Compas Player executable after a compatible Compas bootloader is already installed. They are not instructions for flashing stock or third-party firmware.

## Before installation

1. Confirm the device is a HiBy R1, not another HiBy model.
2. Confirm Compas Player and its compatible bootloader are already installed.
3. Back up the current player binary, Compas settings, and any custom assets.
4. Keep a known-good recovery image and the previous working player binary.
5. Verify the new binary with `file` and SHA-256 before copying it.

## Player-only update

1. Shut down or safely disconnect the R1 before removing its microSD card.
2. On the microSD card, preserve the existing `.compas` directory.
3. Back up `SD/.compas/compas_player` if it exists.
4. Copy the newly built R1 binary to:

   ```text
   SD/.compas/compas_player
   ```

5. Copy one supplied background from `customization/assets/` to a normal image folder on the card.
6. Safely eject the card, insert it into the R1, and reboot.
7. In Compas, select the copied image as the image lock screen.
8. Verify playback, power-button wake, touch, screen timeout, volume buttons, Bluetooth, and USB DAC behavior before treating the build as stable.

## Rollback

Replace `SD/.compas/compas_player` with the backed-up known-good binary and reboot. If the player cannot start, follow the recovery procedure for the exact Compas bootloader version already installed. Do not flash a `.upt` merely because a player-only update failed.

