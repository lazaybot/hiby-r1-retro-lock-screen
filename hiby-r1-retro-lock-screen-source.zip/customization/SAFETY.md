# Safety and compatibility

- This code is for the HiBy R1 target. A filename change does not make it compatible with another model.
- Firmware flashing can make the device temporarily unusable. This repository intentionally excludes proprietary base firmware and ready-to-flash `.upt` packages.
- A player-only binary still requires a compatible Compas installation and bootloader.
- Preserve a recovery image and a known-good player binary before testing.
- USB DAC behavior with every external DAC is not established. Test it rather than assuming compatibility.
- The experimental touch-to-wake work is not included in the stable customization. Keeping the touch rail active increases standby power consumption, and its final behavior was not fully verified.
- A successful compilation or host simulation is not proof of safe operation on physical hardware.

No warranty is provided. See the repository's GPL-3.0 license and upstream notices.

