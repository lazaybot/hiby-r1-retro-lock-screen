# Build from source

## Requirements

- macOS or Linux host
- Git and GNU Make
- A static `mipsel-linux-musl` cross-compiler for the HiBy R1 target
- Network access during the first build so the Makefile can fetch pinned dependencies

Compas Player's upstream [README](../README.md) and [firmware build guide](../docs/HOW_TO_BUILD_A_UPT_FILE.md) remain the authority for the full project and firmware packaging process.

## Player-only build

From the repository root:

```sh
export PATH="/absolute/path/to/mipsel-linux-musl-cross/bin:$PATH"
make target BOARD=r1
file compas_player_target
shasum -a 256 compas_player_target
```

The expected result is a statically linked, 32-bit little-endian MIPS executable. Do not install a host simulator binary or a build for another HiBy model on the R1.

## Host simulator

On a supported Linux system with SDL2 development files:

```sh
make
./compas_player_host
```

The simulator is useful for interface work, but it does not prove that touch, suspend, audio, USB DAC mode, or hardware buttons work on the physical R1.

## Reproducibility note

The final source state in this repository corresponds to the last preserved retro lock-screen working tree. Historical r2-r8 executables were produced during iterative on-device testing, but exact source snapshots were not committed for every binary. Their checksums are retained in [ITERATIONS.md](ITERATIONS.md); they should not be described as reproducible releases.

