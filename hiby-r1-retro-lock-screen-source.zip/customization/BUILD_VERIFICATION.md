# Build verification

The packaged source was cross-compiled for the HiBy R1 on October 28, 2026 using:

```sh
export PATH="/absolute/path/to/mipsel-linux-musl-cross/bin:$PATH"
make target BOARD=r1
```

The first clean invocation generated `libexecinfo/stacktraverse.c` after Make had already evaluated the target list and stopped with a missing-object error. Running the same command again completed successfully. This is an upstream Makefile ordering issue, not a customization source error.

Result:

```text
compas_player_target: ELF 32-bit LSB executable, MIPS, MIPS32 rel2 version 1 (SYSV), statically linked, stripped
SHA-256: 36a7e38dc1ebe2b8a3a4a95259e2f8a10e54783b4597c5bc29189ce4b637a562
Size: approximately 8.0 MiB
```

The build emitted upstream compiler warnings. It also reported that `patches/dr_libs_metadata_hardening.patch` did not apply to the fetched `dr_wav.h`, so the intended WAV/AIFF metadata denial-of-service hardening was not active in this build. That warning should be resolved upstream before presenting this binary as a hardened public release.

Compilation verifies that the packaged source links for the R1 target. This newly built binary has not been installed or tested on physical hardware.
