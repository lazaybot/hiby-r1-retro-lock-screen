# Recorded iteration history

The customization was adjusted directly against a working Compas tree and repeatedly tested on a physical HiBy R1. The compiled artifacts below survive, but exact source snapshots were not committed for each iteration. Therefore this is an evidence log, not a claim that every historical binary can be reproduced from this repository.

| Revision | SHA-256 |
| --- | --- |
| r2 | `e086e3c456889c91765643da051d316e0d8a0722b849a8298c8188918581420b` |
| r3 | `7dfd0ec67d68e687670a6a525e63c714247a50116d45cce3ca27fc640380a727` |
| r4 | `163689d62e2f758cd49273a555285304d6d2730e43e19672d8dcfcf36ae44db3` |
| r5 | `614e4c561a748f9c1e5599afada578675299f3d08fc959c5ade1d9900c53c64d` |
| r6 | `7e064881b7fdc91e05e21e1e86a1f6e55de9f27c28d24006448a5ad06a37d1f2` |
| r7 | `26d54eb1219d2aaa21d53e4b0407f4c8b840dd2ea8c084c11e3442335a5b0c8a` |
| r8 | `adaa5246cd844b2623826de7feb32981a6ca274f35241114c101869ce1223ec1` |

Verified historical evidence includes an r7 copy whose SHA-256 matched both the Mac artifact and the two on-device destinations used during installation. Later work restored normal automatic sleep behavior and added the 10-second timeout choice. The current source includes the final preserved lock-screen layout and timeout changes.

## Current source changes

- `src/ui/gui_lock_screen.c`: retro layout, pixel fonts, colors, positions, and conditional activation
- `src/core/settings.c`: 10-second timeout value
- `src/core/settings.h`: timeout-step count and documentation
- `src/ui/gui.c`: formatting-only continuation line retained from the working tree

## Experimental work kept separate

A touch-to-wake prototype modified backlight and input behavior. It is omitted here because it trades standby battery life for touch availability and the final target build was not fully verified. It should be developed in a separate branch with explicit power measurements and rollback testing.

